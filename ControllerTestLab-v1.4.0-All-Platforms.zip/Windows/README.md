# Controller Test Lab for Windows · 1.4.0

Native x64 Windows desktop controller tester. It uses Windows XInput and the legacy WinMM joystick API, without Python, Java, .NET, or a separately installed runtime.

## Run
1. Download `ControllerTestLab-v1.4.0.exe` or the `ControllerTestLab.exe` from this ZIP.
2. Double-click it on a Windows 10/11 x64 PC.
3. Connect a controller by USB or Bluetooth. It scans at startup; use **RESCAN DEVICES** to scan again.
4. Click a detected controller in the left column, then move the sticks, press buttons, or squeeze triggers.

## Appearance and stick visualizer
- The app launches in a clean light theme. Press **DARK MODE** in the top bar to switch to dark mode, or **LIGHT MODE** to switch back.
- The stick visualization is a fixed dot matrix. Dots near the reported joystick position grow and tint to create a magnifying-lens effect.
- Press **LENS ON / LENS OFF** to enable or disable the visual magnification independently of input readings.

## Controller support
- **XInput:** Xbox controllers and many controllers in XInput mode; reads buttons, sticks and triggers and can send a short rumble pulse when supported.
- **WinMM legacy joystick API:** older controllers exposed by the Windows legacy joystick interface.

Some DirectInput-only and vendor-specific HID controllers may not show up in this edition. The Windows edition focuses on controller checks; the Linux `.deb` edition also contains the audio, display, keyboard, and mouse diagnostics.

## Technical details
The binary is a native x64 PE executable linked against Windows system GUI libraries. The C source and a Linux cross-build script are included in this ZIP. On Linux with Clang and `lld-link` installed, run `sh Build-on-Linux.sh` from the project directory. The environment used to compile this cannot launch Windows GUI programs, so test it with actual hardware on Windows.

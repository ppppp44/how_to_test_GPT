# Controller Test Lab 1.4.0

A lightweight Linux desktop diagnostics workspace for Linux Mint, Ubuntu, and Debian-based systems. Uses Python 3 and Tkinter, with no pip packages or network connection required.

## What's new in 1.4.0

- Added persistent **Light / Dark** appearance settings. The selection is saved in `~/.config/controller-test-lab/settings.json`.
- Updated panel, label, graph, status, and control colors to keep a consistent contrast in both themes.
- Kept the fixed joystick dot matrix and subtle magnifying-lens effect, with a toggle and strength slider in Settings.
- Preserved the organized Controller, Audio devices, and Screen & input sections.
- Updated the app identity to version 1.4.0.

## Install

```bash
sudo apt install ./controller-test-lab_1.4.0_all.deb
```

Launch **Controller Test Lab** from the applications menu or run `controller-test-lab` in a terminal.

## Appearance

Open **Settings** in the upper-right corner, choose **Light** or **Dark**, then press **Save settings**. The choice persists for future launches. In the same panel, you can disable the dot magnification effect or adjust its strength.

## Included diagnostics

- Linux evdev gamepad discovery; live buttons, D-pad, sticks and axes; supported force-feedback rumble.
- Stick dot matrix with magnification lens; raw axis counts; center offset, calibration baseline, recent movement peak, and drift graph scales down to ±0.001%.
- Speaker and microphone discovery with a 440 Hz output test tone and live mic level meter. Captured microphone audio is not recorded to disk.
- Fullscreen display patterns for visual pixel inspection, gradients, grid, checkerboard, color bars, and motion/ghosting checks.
- Keyboard press/release tester, mouse movement/button/scroll tester, and basic display/session information.

## Dependencies

Required: `python3`, `python3-tk`. Recommended optional tools are `x11-xserver-utils`, `pulseaudio-utils`, and `alsa-utils` for enhanced display/audio discovery and tests.

## Notes

- Drift readings are limited to the values Linux's input driver exposes. Firmware filters may hide movement before software receives it.
- Pixel inspection is visual-assisted; normal desktop software cannot directly interrogate the physical health of every LCD pixel.
- Input-device access depends on Linux permissions and controller-driver behavior.

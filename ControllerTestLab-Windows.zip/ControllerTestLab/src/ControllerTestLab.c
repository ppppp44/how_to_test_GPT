/* Controller Test Lab - native Win32 app, no CRT or third-party runtime required. */
typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef short SHORT;
typedef unsigned int UINT;
typedef unsigned long DWORD;
typedef unsigned long ULONG;
typedef long LONG;
typedef int BOOL;
typedef unsigned long long WPARAM;
typedef long long LPARAM;
typedef long long LRESULT;
typedef void *HANDLE;
typedef void *HWND;
typedef void *HINSTANCE;
typedef void *HICON;
typedef void *HCURSOR;
typedef void *HBRUSH;
typedef void *HDC;
typedef void *HPEN;
typedef void *HFONT;
typedef void *HGDIOBJ;
typedef const char *LPCSTR;
typedef char *LPSTR;
typedef void *LPVOID;
typedef unsigned long long UINT_PTR;
typedef LRESULT (__attribute__((stdcall)) *WNDPROC)(HWND, UINT, WPARAM, LPARAM);

#define WINAPI __attribute__((stdcall))
#define CALLBACK __attribute__((stdcall))
#define TRUE 1
#define FALSE 0
#define NULL ((void*)0)
#define RGB(r,g,b) ((DWORD)(((BYTE)(r)) | ((WORD)((BYTE)(g)) << 8) | (((DWORD)(BYTE)(b)) << 16)))
#define WM_CREATE 0x0001
#define WM_DESTROY 0x0002
#define WM_SIZE 0x0005
#define WM_PAINT 0x000F
#define WM_ERASEBKGND 0x0014
#define WM_TIMER 0x0113
#define WM_LBUTTONDOWN 0x0201
#define WS_OVERLAPPEDWINDOW 0x00CF0000UL
#define CW_USEDEFAULT ((int)0x80000000UL)
#define SW_SHOW 5
#define TRANSPARENT 1
#define FW_NORMAL 400
#define FW_BOLD 700
#define JOY_RETURNALL 0x000000FFUL
#define XINPUT_GAMEPAD_DPAD_UP 0x0001
#define XINPUT_GAMEPAD_DPAD_DOWN 0x0002
#define XINPUT_GAMEPAD_DPAD_LEFT 0x0004
#define XINPUT_GAMEPAD_DPAD_RIGHT 0x0008
#define XINPUT_GAMEPAD_START 0x0010
#define XINPUT_GAMEPAD_BACK 0x0020
#define XINPUT_GAMEPAD_LEFT_THUMB 0x0040
#define XINPUT_GAMEPAD_RIGHT_THUMB 0x0080
#define XINPUT_GAMEPAD_LEFT_SHOULDER 0x0100
#define XINPUT_GAMEPAD_RIGHT_SHOULDER 0x0200
#define XINPUT_GAMEPAD_A 0x1000
#define XINPUT_GAMEPAD_B 0x2000
#define XINPUT_GAMEPAD_X 0x4000
#define XINPUT_GAMEPAD_Y 0x8000

__declspec(dllimport) HINSTANCE WINAPI GetModuleHandleA(LPCSTR);
__declspec(dllimport) HANDLE WINAPI LoadLibraryA(LPCSTR);
__declspec(dllimport) void * WINAPI GetProcAddress(HANDLE, LPCSTR);
__declspec(dllimport) void WINAPI ExitProcess(UINT);
__declspec(dllimport) unsigned short WINAPI RegisterClassA(const void*);
__declspec(dllimport) HWND WINAPI CreateWindowExA(DWORD,LPCSTR,LPCSTR,DWORD,int,int,int,int,HWND,HANDLE,HINSTANCE,LPVOID);
__declspec(dllimport) BOOL WINAPI ShowWindow(HWND,int);
__declspec(dllimport) BOOL WINAPI UpdateWindow(HWND);
__declspec(dllimport) int WINAPI GetMessageA(void*,HWND,UINT,UINT);
__declspec(dllimport) BOOL WINAPI TranslateMessage(const void*);
__declspec(dllimport) LRESULT WINAPI DispatchMessageA(const void*);
__declspec(dllimport) LRESULT WINAPI DefWindowProcA(HWND,UINT,WPARAM,LPARAM);
__declspec(dllimport) void WINAPI PostQuitMessage(int);
__declspec(dllimport) HDC WINAPI BeginPaint(HWND,void*);
__declspec(dllimport) BOOL WINAPI EndPaint(HWND,const void*);
__declspec(dllimport) BOOL WINAPI InvalidateRect(HWND,const void*,BOOL);
__declspec(dllimport) UINT_PTR WINAPI SetTimer(HWND,UINT_PTR,UINT,void*);
__declspec(dllimport) BOOL WINAPI KillTimer(HWND,UINT_PTR);
__declspec(dllimport) BOOL WINAPI GetClientRect(HWND,void*);
__declspec(dllimport) HBRUSH WINAPI CreateSolidBrush(DWORD);
__declspec(dllimport) HPEN WINAPI CreatePen(int,int,DWORD);
__declspec(dllimport) HGDIOBJ WINAPI SelectObject(HDC,HGDIOBJ);
__declspec(dllimport) BOOL WINAPI DeleteObject(HGDIOBJ);
__declspec(dllimport) BOOL WINAPI TextOutA(HDC,int,int,LPCSTR,int);
__declspec(dllimport) DWORD WINAPI SetTextColor(HDC,DWORD);
__declspec(dllimport) int WINAPI SetBkMode(HDC,int);
__declspec(dllimport) BOOL WINAPI Rectangle(HDC,int,int,int,int);
__declspec(dllimport) BOOL WINAPI RoundRect(HDC,int,int,int,int,int,int);
__declspec(dllimport) BOOL WINAPI Ellipse(HDC,int,int,int,int);
__declspec(dllimport) BOOL WINAPI MoveToEx(HDC,int,int,void*);
__declspec(dllimport) BOOL WINAPI LineTo(HDC,int,int);
__declspec(dllimport) HFONT WINAPI CreateFontA(int,int,int,int,int,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,LPCSTR);

/* Keep the linker independent of the C runtime. */
int _fltused = 0;
void *memset(void *d, int c, unsigned long n) { BYTE *p=(BYTE*)d; unsigned long i; for(i=0;i<n;i++)p[i]=(BYTE)c; return d; }
void *memcpy(void *d, const void *s, unsigned long n) { BYTE *a=(BYTE*)d; const BYTE *b=(const BYTE*)s; unsigned long i; for(i=0;i<n;i++)a[i]=b[i]; return d; }

struct POINT { LONG x; LONG y; };
struct RECT { LONG left; LONG top; LONG right; LONG bottom; };
struct WNDCLASSA { UINT style; WNDPROC lpfnWndProc; int cbClsExtra; int cbWndExtra; HINSTANCE hInstance; HICON hIcon; HCURSOR hCursor; HBRUSH hbrBackground; LPCSTR lpszMenuName; LPCSTR lpszClassName; };
struct MSG { HWND hwnd; UINT message; WPARAM wParam; LPARAM lParam; DWORD time; struct POINT pt; DWORD lPrivate; };
struct PAINTSTRUCT { HDC hdc; BOOL fErase; struct RECT rcPaint; BOOL fRestore; BOOL fIncUpdate; BYTE rgbReserved[32]; };

struct XINPUT_GAMEPAD { WORD wButtons; BYTE bLeftTrigger; BYTE bRightTrigger; SHORT sThumbLX; SHORT sThumbLY; SHORT sThumbRX; SHORT sThumbRY; };
struct XINPUT_STATE { DWORD dwPacketNumber; struct XINPUT_GAMEPAD Gamepad; };
struct XINPUT_VIBRATION { WORD wLeftMotorSpeed; WORD wRightMotorSpeed; };
typedef DWORD (WINAPI *XInputGetStateFn)(DWORD, struct XINPUT_STATE*);
typedef DWORD (WINAPI *XInputSetStateFn)(DWORD, struct XINPUT_VIBRATION*);
struct JOYINFOEX { DWORD dwSize,dwFlags,dwXpos,dwYpos,dwZpos,dwRpos,dwUpos,dwVpos,dwButtons,dwButtonNumber,dwPOV,dwReserved1,dwReserved2; };
typedef UINT (WINAPI *JoyGetNumDevsFn)(void);
typedef UINT (WINAPI *JoyGetPosExFn)(UINT, struct JOYINFOEX*);

#define DEV_XINPUT 1
#define DEV_LEGACY 2
#define MAX_DEVICES 20
struct Device { int type; int slot; char name[48]; };
struct Snapshot { int connected; int type; int lx,ly,rx,ry; int lt,rt; DWORD buttons; DWORD pov; DWORD axis3,axis4; };

static HINSTANCE g_instance;
static HWND g_window;
static int g_width=1090, g_height=755;
static struct Device g_devices[MAX_DEVICES];
static int g_device_count=0, g_selected=0;
static struct Snapshot g_snap;
static char g_status[160]="Connect a gamepad, then press RESCAN DEVICES.";
static int g_status_kind=2;
static int g_scan_ticks=0, g_vibration_ticks=0;
static int g_rescan_x=850, g_rescan_y=27, g_rescan_w=200, g_rescan_h=43;
static int g_vibe_x=795, g_vibe_y=620, g_vibe_w=235, g_vibe_h=47;
static HFONT g_font=NULL, g_font_bold=NULL, g_font_title=NULL, g_font_small=NULL;
static HANDLE g_xinput_module=NULL, g_winmm_module=NULL;
static XInputGetStateFn g_xget=NULL;
static XInputSetStateFn g_xset=NULL;
static JoyGetNumDevsFn g_joynum=NULL;
static JoyGetPosExFn g_joypos=NULL;

static int str_len(const char *s) { int n=0; while(s && s[n])n++; return n; }
static void str_copy(char *d,const char *s,int max) { int i=0; if(!s){if(max)d[0]=0;return;} while(i<max-1 && s[i]){d[i]=s[i];i++;} if(max)d[i]=0; }
static int str_eq(const char *a,const char *b) { int i=0; while(a[i]&&b[i]&&a[i]==b[i])i++; return a[i]==b[i]; }
static int abs_i(int x) { return x<0?-x:x; }
static int min_i(int a,int b){return a<b?a:b;}
static int max_i(int a,int b){return a>b?a:b;}
static void int_str(char *out,int value) {
    char tmp[16]; int n=0,i=0,neg=0; unsigned int v;
    if(value<0){neg=1;v=(unsigned int)(-value);}else v=(unsigned int)value;
    do { tmp[n++]=(char)('0'+(v%10)); v/=10; } while(v && n<14);
    if(neg)out[i++]='-'; while(n>0)out[i++]=tmp[--n]; out[i]=0;
}
static void set_status(const char *s,int kind) { str_copy(g_status,s,sizeof(g_status)); g_status_kind=kind; }

static void load_input_apis(void) {
    if(!g_xget) {
        g_xinput_module=LoadLibraryA("xinput1_4.dll");
        if(!g_xinput_module)g_xinput_module=LoadLibraryA("xinput1_3.dll");
        if(!g_xinput_module)g_xinput_module=LoadLibraryA("xinput9_1_0.dll");
        if(g_xinput_module) { g_xget=(XInputGetStateFn)GetProcAddress(g_xinput_module,"XInputGetState"); g_xset=(XInputSetStateFn)GetProcAddress(g_xinput_module,"XInputSetState"); }
    }
    if(!g_joypos) {
        g_winmm_module=LoadLibraryA("winmm.dll");
        if(g_winmm_module) { g_joynum=(JoyGetNumDevsFn)GetProcAddress(g_winmm_module,"joyGetNumDevs"); g_joypos=(JoyGetPosExFn)GetProcAddress(g_winmm_module,"joyGetPosEx"); }
    }
}
static int xinput_connected(int slot) { struct XINPUT_STATE st; if(!g_xget)return 0; memset(&st,0,sizeof(st)); return g_xget((DWORD)slot,&st)==0; }
static int legacy_read(int slot,struct JOYINFOEX *out) { if(!g_joypos)return 0; memset(out,0,sizeof(*out)); out->dwSize=(DWORD)sizeof(*out); out->dwFlags=JOY_RETURNALL; return g_joypos((UINT)slot,out)==0; }
static void scan_devices(void) {
    struct Device fresh[MAX_DEVICES]; int n=0,i,oldtype=-1,oldslot=-1,found=-1,changed=0;
    struct JOYINFOEX ji;
    if(g_selected>=0 && g_selected<g_device_count){oldtype=g_devices[g_selected].type;oldslot=g_devices[g_selected].slot;}
    load_input_apis(); memset(fresh,0,sizeof(fresh));
    for(i=0;i<4 && n<MAX_DEVICES;i++) if(xinput_connected(i)) {
        fresh[n].type=DEV_XINPUT; fresh[n].slot=i;
        str_copy(fresh[n].name, i==0?"XInput controller 1":i==1?"XInput controller 2":i==2?"XInput controller 3":"XInput controller 4",sizeof(fresh[n].name)); n++;
    }
    if(g_joynum && g_joypos) {
        UINT count=g_joynum(); if(count>16)count=16;
        for(i=0;i<(int)count && n<MAX_DEVICES;i++) if(legacy_read(i,&ji)) {
            fresh[n].type=DEV_LEGACY; fresh[n].slot=i;
            if(i==0)str_copy(fresh[n].name,"Legacy joystick 1",sizeof(fresh[n].name));
            else if(i==1)str_copy(fresh[n].name,"Legacy joystick 2",sizeof(fresh[n].name));
            else { str_copy(fresh[n].name,"Legacy joystick",sizeof(fresh[n].name)); }
            n++;
        }
    }
    if(n!=g_device_count)changed=1;
    else for(i=0;i<n;i++) if(fresh[i].type!=g_devices[i].type || fresh[i].slot!=g_devices[i].slot){changed=1;break;}
    if(changed) {
        memset(g_devices,0,sizeof(g_devices)); memcpy(g_devices,fresh,sizeof(fresh)); g_device_count=n;
        if(n==0)g_selected=0;
        else { for(i=0;i<n;i++)if(g_devices[i].type==oldtype&&g_devices[i].slot==oldslot){found=i;break;} g_selected=found>=0?found:min_i(g_selected,n-1); if(g_selected<0)g_selected=0; set_status("Controller detected. Move a stick or press a button.",1); }
    }
    if(g_device_count==0) { memset(&g_snap,0,sizeof(g_snap)); set_status("No controller detected. Connect USB or Bluetooth and scan again.",2); }
}
static int get_snapshot(void) {
    struct XINPUT_STATE xs; struct JOYINFOEX ji; struct Device *d;
    memset(&g_snap,0,sizeof(g_snap));
    if(g_device_count<=0 || g_selected<0 || g_selected>=g_device_count)return 0;
    d=&g_devices[g_selected]; g_snap.type=d->type;
    if(d->type==DEV_XINPUT) {
        if(!g_xget || g_xget((DWORD)d->slot,&xs)!=0)return 0;
        g_snap.connected=1; g_snap.buttons=xs.Gamepad.wButtons; g_snap.lt=xs.Gamepad.bLeftTrigger; g_snap.rt=xs.Gamepad.bRightTrigger;
        g_snap.lx=(int)xs.Gamepad.sThumbLX*1000/32767; g_snap.ly=(int)xs.Gamepad.sThumbLY*1000/32767;
        g_snap.rx=(int)xs.Gamepad.sThumbRX*1000/32767; g_snap.ry=(int)xs.Gamepad.sThumbRY*1000/32767;
        if(g_snap.lx>1000)g_snap.lx=1000;if(g_snap.lx< -1000)g_snap.lx=-1000;
        if(g_snap.ly>1000)g_snap.ly=1000;if(g_snap.ly< -1000)g_snap.ly=-1000;
        if(g_snap.rx>1000)g_snap.rx=1000;if(g_snap.rx< -1000)g_snap.rx=-1000;
        if(g_snap.ry>1000)g_snap.ry=1000;if(g_snap.ry< -1000)g_snap.ry=-1000;
        return 1;
    }
    if(d->type==DEV_LEGACY && legacy_read(d->slot,&ji)) {
        g_snap.connected=1; g_snap.buttons=ji.dwButtons; g_snap.pov=ji.dwPOV;
        g_snap.lx=(int)(ji.dwXpos*2000UL/65535UL)-1000; g_snap.ly=(int)(ji.dwYpos*2000UL/65535UL)-1000;
        g_snap.rx=(int)(ji.dwRpos*2000UL/65535UL)-1000; g_snap.ry=(int)(ji.dwUpos*2000UL/65535UL)-1000;
        g_snap.axis3=(DWORD)(ji.dwZpos*1000UL/65535UL);g_snap.axis4=(DWORD)(ji.dwVpos*1000UL/65535UL);
        g_snap.lt=(int)(g_snap.axis3*255UL/1000UL);g_snap.rt=(int)(g_snap.axis4*255UL/1000UL);
        return 1;
    }
    return 0;
}
static HGDIOBJ choose_font(HDC dc,HFONT f) { return SelectObject(dc,(HGDIOBJ)f); }
static void draw_text(HDC dc,int x,int y,const char *s,DWORD col,HFONT f) { HGDIOBJ old=choose_font(dc,f); SetTextColor(dc,col); TextOutA(dc,x,y,s,str_len(s)); SelectObject(dc,old); }
static void draw_center(HDC dc,int x,int y,int w,int h,const char *s,DWORD col,HFONT f,int fs) { int tw=str_len(s)*fs*3/5; draw_text(dc,x+(w-tw)/2,y+(h-fs)/2-1,s,col,f); }
static void draw_fill(HDC dc,int x,int y,int w,int h,DWORD fill,DWORD edge,int radius) { HBRUSH b=CreateSolidBrush(fill); HPEN p=CreatePen(0,1,edge); HGDIOBJ ob=SelectObject(dc,b),op=SelectObject(dc,p); if(radius)RoundRect(dc,x,y,x+w,y+h,radius,radius);else Rectangle(dc,x,y,x+w,y+h); SelectObject(dc,op);SelectObject(dc,ob);DeleteObject(p);DeleteObject(b); }
static void draw_line(HDC dc,int x1,int y1,int x2,int y2,DWORD col,int width) { HPEN p=CreatePen(0,width,col); HGDIOBJ old=SelectObject(dc,p);MoveToEx(dc,x1,y1,NULL);LineTo(dc,x2,y2);SelectObject(dc,old);DeleteObject(p); }
static void draw_circle(HDC dc,int cx,int cy,int r,DWORD fill,DWORD edge,int ew) { HBRUSH b=CreateSolidBrush(fill); HPEN p=CreatePen(0,ew,edge);HGDIOBJ ob=SelectObject(dc,b),op=SelectObject(dc,p);Ellipse(dc,cx-r,cy-r,cx+r,cy+r);SelectObject(dc,op);SelectObject(dc,ob);DeleteObject(p);DeleteObject(b); }
static void draw_number(HDC dc,int x,int y,int value,DWORD col,HFONT f) { char b[20];int_str(b,value);draw_text(dc,x,y,b,col,f); }
static void draw_pill(HDC dc,int x,int y,int w,int h,const char *label,int pressed) {
    DWORD fill=pressed?RGB(25,82,88):RGB(26,35,51), edge=pressed?RGB(58,222,226):RGB(48,63,84), txt=pressed?RGB(151,255,232):RGB(169,184,207);
    draw_fill(dc,x,y,w,h,fill,edge,9);draw_center(dc,x,y,w,h,label,txt,g_font_bold,10);
}
static int btn(DWORD mask) { return (g_snap.buttons&mask)!=0; }
static void draw_stick(HDC dc,int x,int y,int panelw,const char *title,int sx,int sy,int isright) {
    int cx=x+panelw/2, cy=y+137, r=69, px=cx+(sx*(r-8))/1000, py=cy-(sy*(r-8))/1000;
    DWORD aqua=RGB(51,218,238), mint=RGB(126,247,181), muted=RGB(69,86,111);
    char buf[64]; int off,drift=max_i(abs_i(sx),abs_i(sy));
    draw_fill(dc,x,y,panelw,228,RGB(19,27,42),RGB(39,54,76),16);
    draw_text(dc,x+18,y+15,title,RGB(138,222,245),g_font_bold);
    draw_circle(dc,cx,cy,r,RGB(14,21,34),muted,1);
    draw_circle(dc,cx,cy,(r*25)/100,RGB(19,28,43),RGB(48,67,92),1);
    draw_line(dc,cx-r,cy,cx+r,cy,RGB(42,55,76),1); draw_line(dc,cx,cy-r,cx,cy+r,RGB(42,55,76),1);
    draw_circle(dc,cx,cy,3,RGB(112,132,159),RGB(112,132,159),1);
    draw_circle(dc,px,py,10,RGB(44,204,231),RGB(176,249,255),2);
    draw_text(dc,x+18,y+196,"X",RGB(136,155,181),g_font_small); draw_number(dc,x+34,y+196,sx/10,RGB(228,238,249),g_font_bold);
    draw_text(dc,x+92,y+196,"Y",RGB(136,155,181),g_font_small); draw_number(dc,x+108,y+196,sy/10,RGB(228,238,249),g_font_bold);
    draw_text(dc,x+panelw-96,y+52,"CENTER",RGB(118,138,164),g_font_small);
    draw_text(dc,x+panelw-96,y+74,drift>80?"CHECK DRIFT":"NEAR CENTER",drift>80?RGB(255,174,114):mint,g_font_bold);
    draw_text(dc,x+panelw-96,y+103,"OFFSET",RGB(118,138,164),g_font_small);
    off=drift/10; int_str(buf,off);{int l=str_len(buf);buf[l++]='%';buf[l]=0;}draw_text(dc,x+panelw-96,y+125,buf,RGB(227,238,249),g_font_bold);
}
static void draw_trigger(HDC dc,int x,int y,int w,const char *name,int value) {
    int bw=(w-2)*value/255; char buf[20];
    draw_text(dc,x,y,name,RGB(173,190,215),g_font_bold);
    draw_number(dc,x+w-34,y,value,RGB(232,240,251),g_font_bold);
    draw_fill(dc,x,y+23,w,14,RGB(34,45,64),RGB(34,45,64),7);
    if(value>0)draw_fill(dc,x+1,y+24,bw,12,RGB(53,207,224),RGB(53,207,224),6);
}
static int hit(int x,int y,int rx,int ry,int rw,int rh){return x>=rx&&y>=ry&&x<rx+rw&&y<ry+rh;}
static void paint_app(HDC dc) {
    int i; DWORD bg=RGB(10,15,26), card=RGB(18,26,41), edge=RGB(38,53,75), white=RGB(235,242,252), muted=RGB(133,151,177), aqua=RGB(65,217,238), mint=RGB(126,247,181), amber=RGB(255,190,115);
    HBRUSH back=CreateSolidBrush(bg);struct RECT r={0,0,g_width,g_height}; HGDIOBJ oldbr=SelectObject(dc,back);HPEN nop=CreatePen(0,1,bg);HGDIOBJ oldp=SelectObject(dc,nop);Rectangle(dc,0,0,g_width,g_height);SelectObject(dc,oldp);SelectObject(dc,oldbr);DeleteObject(nop);DeleteObject(back);SetBkMode(dc,TRANSPARENT);
    draw_text(dc,25,23,"CONTROLLER TEST LAB",RGB(100,226,248),g_font_title);
    draw_text(dc,27,58,"REAL-TIME GAMEPAD DIAGNOSTICS",muted,g_font_small);
    draw_fill(dc,g_rescan_x,g_rescan_y,g_rescan_w,g_rescan_h,RGB(24,43,61),RGB(55,104,127),11);
    draw_center(dc,g_rescan_x,g_rescan_y,g_rescan_w,g_rescan_h,"RESCAN DEVICES",RGB(146,237,249),g_font_bold,11);
    draw_line(dc,25,85,g_width-25,85,RGB(35,48,68),1);

    draw_fill(dc,24,105,246,g_height-130,card,edge,14);
    draw_text(dc,42,124,"CONNECTED DEVICES",aqua,g_font_bold);
    draw_text(dc,42,150,"Choose a controller",muted,g_font_small);
    if(g_device_count==0) {
        draw_circle(dc,147,240,28,RGB(24,36,53),RGB(55,75,101),2);
        draw_text(dc,132,231,"?",RGB(149,184,207),g_font_title);
        draw_center(dc,40,281,213,30,"No controllers found",white,g_font_bold,11);
        draw_center(dc,40,306,213,24,"Connect a controller",muted,g_font_small,9);
        draw_center(dc,40,327,213,24,"then press RESCAN",muted,g_font_small,9);
    } else {
        for(i=0;i<g_device_count && i<10;i++) {
            int yy=181+i*53, selected=(i==g_selected); char idbuf[24];
            draw_fill(dc,36,yy,222,44,selected?RGB(24,55,67):RGB(22,31,47),selected?RGB(55,198,219):RGB(38,53,75),9);
            draw_circle(dc,53,yy+22,4,selected?mint:RGB(77,103,131),selected?mint:RGB(77,103,131),1);
            draw_text(dc,66,yy+7,g_devices[i].name,selected?white:RGB(179,194,215),g_font_bold);
            if(g_devices[i].type==DEV_XINPUT)str_copy(idbuf,"XINPUT",sizeof(idbuf));else str_copy(idbuf,"LEGACY API",sizeof(idbuf));
            draw_text(dc,66,yy+25,idbuf,selected?RGB(119,232,245):muted,g_font_small);
        }
    }
    draw_text(dc,42,g_height-56,"XInput + WinMM",RGB(118,146,174),g_font_small);
    draw_text(dc,42,g_height-38,"Windows native APIs",RGB(91,112,140),g_font_small);

    int mx=292, mw=g_width-316;
    draw_fill(dc,mx,105,mw,65,card,edge,13);
    if(g_snap.connected) {
        draw_circle(dc,mx+25,137,6,mint,mint,1);
        draw_text(dc,mx+43,117,"CONTROLLER CONNECTED",mint,g_font_bold);
        draw_text(dc,mx+43,140,g_devices[g_selected].name,white,g_font);
        draw_text(dc,mx+mw-260,130,g_snap.type==DEV_XINPUT?"LIVE INPUT  /  XINPUT":"LIVE INPUT  /  LEGACY",aqua,g_font_bold);
    } else {
        draw_circle(dc,mx+25,137,6,amber,amber,1);
        draw_text(dc,mx+43,117,"WAITING FOR INPUT",amber,g_font_bold);
        draw_text(dc,mx+43,140,g_status,g_status_kind==1?mint:muted,g_font_small);
    }

    draw_stick(dc,mx,184, (mw-14)/2,"LEFT STICK",g_snap.lx,g_snap.ly,0);
    draw_stick(dc,mx+(mw-14)/2+14,184, (mw-14)/2,"RIGHT STICK",g_snap.rx,g_snap.ry,1);

    int panelY=429, panelH=250, btnW=72, gap=9, startX=mx+17, startY=487, rowgap=43;
    draw_fill(dc,mx,panelY,470,panelH,card,edge,14);
    draw_text(dc,mx+18,panelY+16,"BUTTON MATRIX",aqua,g_font_bold);
    draw_text(dc,mx+18,panelY+39,g_snap.type==DEV_LEGACY?"Legacy buttons are shown by index":"Buttons light up while held",muted,g_font_small);
    if(g_snap.type==DEV_XINPUT) {
        const char *labels[14]={"A","B","X","Y","LB","RB","LS","RS","VIEW","MENU","UP","DOWN","LEFT","RIGHT"};
        DWORD masks[14]={XINPUT_GAMEPAD_A,XINPUT_GAMEPAD_B,XINPUT_GAMEPAD_X,XINPUT_GAMEPAD_Y,XINPUT_GAMEPAD_LEFT_SHOULDER,XINPUT_GAMEPAD_RIGHT_SHOULDER,XINPUT_GAMEPAD_LEFT_THUMB,XINPUT_GAMEPAD_RIGHT_THUMB,XINPUT_GAMEPAD_BACK,XINPUT_GAMEPAD_START,XINPUT_GAMEPAD_DPAD_UP,XINPUT_GAMEPAD_DPAD_DOWN,XINPUT_GAMEPAD_DPAD_LEFT,XINPUT_GAMEPAD_DPAD_RIGHT};
        for(i=0;i<14;i++){int row=i/5,col=i%5;draw_pill(dc,startX+col*(btnW+gap),startY+row*rowgap,btnW,31,labels[i],g_snap.connected&&btn(masks[i]));}
    } else if(g_snap.type==DEV_LEGACY) {
        for(i=0;i<16;i++){char label[8]="B0";label[1]=(char)('1'+(i%9));if(i>=9){label[1]=(char)('1'+(i/10));label[2]=(char)('0'+(i%10));label[3]=0;}else label[2]=0;draw_pill(dc,startX+(i%5)*(btnW+gap),startY+(i/5)*rowgap,btnW,31,label,g_snap.connected&&((g_snap.buttons>>i)&1));}
    } else {
        for(i=0;i<15;i++)draw_pill(dc,startX+(i%5)*(btnW+gap),startY+(i/5)*rowgap,btnW,31,"--",0);
    }

    int tx=mx+486, tw=mw-486;
    draw_fill(dc,tx,panelY,tw,panelH,card,edge,14);
    draw_text(dc,tx+17,panelY+16,g_snap.type==DEV_XINPUT?"TRIGGERS":"EXTRA AXES",aqua,g_font_bold);
    draw_trigger(dc,tx+17,panelY+59,tw-34,g_snap.type==DEV_XINPUT?"LEFT TRIGGER":"AXIS Z",g_snap.lt);
    draw_trigger(dc,tx+17,panelY+119,tw-34,g_snap.type==DEV_XINPUT?"RIGHT TRIGGER":"AXIS V",g_snap.rt);
    draw_fill(dc,g_vibe_x,g_vibe_y,g_vibe_w,g_vibe_h,(g_snap.connected&&g_snap.type==DEV_XINPUT)?RGB(27,69,76):RGB(32,39,52),(g_snap.connected&&g_snap.type==DEV_XINPUT)?RGB(53,179,187):RGB(52,62,80),10);
    draw_center(dc,g_vibe_x,g_vibe_y,g_vibe_w,g_vibe_h,"TEST VIBRATION",(g_snap.connected&&g_snap.type==DEV_XINPUT)?RGB(162,255,237):RGB(109,125,150),g_font_bold,11);
    draw_text(dc,tx+17,panelY+200,g_snap.type==DEV_XINPUT?"Sends a brief rumble pulse":"Rumble not available on this input API",muted,g_font_small);

    if(g_snap.connected) {
        char line[64]; int maxdrift=max_i(max_i(abs_i(g_snap.lx),abs_i(g_snap.ly)),max_i(abs_i(g_snap.rx),abs_i(g_snap.ry)));
        draw_text(dc,mx+1,g_height-57,g_status,g_status_kind==2?amber:g_status_kind==1?mint:muted,g_font_small);
        draw_text(dc,mx+1,g_height-35,"STICK CENTER CHECK:",muted,g_font_small);
        if(maxdrift>120) draw_text(dc,mx+130,g_height-35,"Movement detected - release both sticks to check drift",amber,g_font_small);
        else draw_text(dc,mx+130,g_height-35,"Near center. Leave sticks untouched to check for unwanted movement.",mint,g_font_small);
    }
}

static void rescan_click(void) { scan_devices(); if(g_device_count>0)set_status("Devices rescanned. Live inputs are updating.",1); InvalidateRect(g_window,NULL,TRUE); }
static void start_vibration(void) {
    struct XINPUT_VIBRATION v; DWORD ret;
    if(!g_snap.connected||g_snap.type!=DEV_XINPUT||!g_xset){set_status("Vibration test needs a selected XInput controller.",2);return;}
    v.wLeftMotorSpeed=42000;v.wRightMotorSpeed=42000;ret=g_xset((DWORD)g_devices[g_selected].slot,&v);
    if(ret==0){g_vibration_ticks=12;set_status("Rumble command sent for about 600 ms, if supported by this controller.",1);}
    else set_status("Windows could not start rumble for this controller.",2);
    InvalidateRect(g_window,NULL,TRUE);
}
static LRESULT CALLBACK window_proc(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp) {
    if(msg==WM_CREATE){g_window=hwnd;load_input_apis();scan_devices();SetTimer(hwnd,1,50,NULL);return 0;}
    if(msg==WM_SIZE){g_width=(int)(lp&0xFFFF);g_height=(int)((lp>>16)&0xFFFF);InvalidateRect(hwnd,NULL,TRUE);return 0;}
    if(msg==WM_ERASEBKGND)return 1;
    if(msg==WM_TIMER){
        if(wp==1){g_scan_ticks++; if(g_scan_ticks>=20){g_scan_ticks=0;scan_devices();} if(!get_snapshot()){if(g_device_count>0)set_status("Controller stopped responding. Try reconnecting it.",2);} if(g_vibration_ticks>0){g_vibration_ticks--;if(g_vibration_ticks==0&&g_xset&&g_device_count>0&&g_selected<g_device_count&&g_devices[g_selected].type==DEV_XINPUT){struct XINPUT_VIBRATION v={0,0};g_xset((DWORD)g_devices[g_selected].slot,&v);}} InvalidateRect(hwnd,NULL,TRUE);}return 0;
    }
    if(msg==WM_LBUTTONDOWN){int x=(int)(lp&0xFFFF),y=(int)((lp>>16)&0xFFFF),i;
        if(hit(x,y,g_rescan_x,g_rescan_y,g_rescan_w,g_rescan_h)){rescan_click();return 0;}
        if(g_device_count>0){for(i=0;i<g_device_count&&i<10;i++){if(hit(x,y,36,181+i*53,222,44)){g_selected=i;set_status("Controller selected. Move a stick or press a button.",1);get_snapshot();InvalidateRect(hwnd,NULL,TRUE);return 0;}}}
        if(hit(x,y,g_vibe_x,g_vibe_y,g_vibe_w,g_vibe_h)){start_vibration();return 0;} return 0;
    }
    if(msg==WM_PAINT){struct PAINTSTRUCT ps;HDC dc=BeginPaint(hwnd,&ps);paint_app(dc);EndPaint(hwnd,&ps);return 0;}
    if(msg==WM_DESTROY){if(g_vibration_ticks>0&&g_xset&&g_device_count>0&&g_selected<g_device_count&&g_devices[g_selected].type==DEV_XINPUT){struct XINPUT_VIBRATION v={0,0};g_xset((DWORD)g_devices[g_selected].slot,&v);}KillTimer(hwnd,1);PostQuitMessage(0);return 0;}
    return DefWindowProcA(hwnd,msg,wp,lp);
}

void app_entry(void) {
    struct WNDCLASSA wc; struct MSG msg; HBRUSH bg; int gm;
    g_instance=GetModuleHandleA(NULL);
    g_font=CreateFontA(15,0,0,0,FW_NORMAL,0,0,0,1,0,0,5,0,"Segoe UI");
    g_font_bold=CreateFontA(15,0,0,0,FW_BOLD,0,0,0,1,0,0,5,0,"Segoe UI");
    g_font_title=CreateFontA(24,0,0,0,FW_BOLD,0,0,0,1,0,0,5,0,"Segoe UI");
    g_font_small=CreateFontA(11,0,0,0,FW_NORMAL,0,0,0,1,0,0,5,0,"Segoe UI");
    memset(&wc,0,sizeof(wc)); wc.lpfnWndProc=window_proc; wc.hInstance=g_instance; wc.lpszClassName="ControllerTestLabWindow"; bg=CreateSolidBrush(RGB(10,15,26));wc.hbrBackground=bg;
    if(!RegisterClassA(&wc)){ExitProcess(2);return;}
    g_window=CreateWindowExA(0,"ControllerTestLabWindow","Controller Test Lab",WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,1120,800,NULL,NULL,g_instance,NULL);
    if(!g_window){ExitProcess(3);return;}
    ShowWindow(g_window,SW_SHOW);UpdateWindow(g_window);
    while((gm=GetMessageA(&msg,NULL,0,0))>0){TranslateMessage(&msg);DispatchMessageA(&msg);}
    ExitProcess(0);
}

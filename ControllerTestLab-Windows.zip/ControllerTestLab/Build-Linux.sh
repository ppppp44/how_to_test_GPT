#!/usr/bin/env sh
set -eu
# Run from this folder on Linux with Clang and lld-link installed.
CLANG="${CLANG:-clang}"
LLD_LINK="${LLD_LINK:-lld-link}"
mkdir -p build
cd build
"$LLD_LINK" /lib /def:../src/kernel32.def /machine:x64 /out:kernel32.lib
"$LLD_LINK" /lib /def:../src/user32.def /machine:x64 /out:user32.lib
"$LLD_LINK" /lib /def:../src/gdi32.def /machine:x64 /out:gdi32.lib
"$CLANG" --target=x86_64-pc-windows-msvc -O2 -c -ffreestanding -fno-stack-protector -fno-builtin -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables ../src/ControllerTestLab.c -o ControllerTestLab.obj
"$LLD_LINK" /out:ControllerTestLab.exe /subsystem:windows /entry:app_entry /nodefaultlib /machine:x64 /dynamicbase /nxcompat ControllerTestLab.obj kernel32.lib user32.lib gdi32.lib
cp ControllerTestLab.exe ../ControllerTestLab.exe
printf 'Built ../ControllerTestLab.exe\n'

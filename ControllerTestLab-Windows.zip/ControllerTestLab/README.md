# Controller Test Lab

**A small, standalone Windows gamepad tester.** The app is a native 64-bit Windows GUI executable and does not require Python, Java, .NET, or a separate runtime installation.

## Run it

1. Download `ControllerTestLab.exe` to a Windows 10/11 PC.
2. Double-click it.
3. Connect a controller over USB or Bluetooth and click **RESCAN DEVICES** if it is not listed.
4. Select the controller on the left, then press buttons, move both sticks, and squeeze triggers. Active buttons light up and the stick markers move live.
5. Leave the sticks untouched to check their center offset. A persistent offset can suggest drift, but the result is a diagnostic clue rather than a definitive repair verdict.
6. Click **TEST VIBRATION** to send a short rumble command to a selected XInput controller.

## Controller support

- **XInput:** Xbox controllers and many third-party controllers operating in XInput mode. Reads buttons, both sticks, analog triggers, and sends a brief vibration command where supported.
- **Windows legacy joystick API (WinMM):** older gamepads/joysticks that Windows exposes through that interface.

Some controllers expose only DirectInput or a different HID interface and may not appear in this first version. For those, switch the controller to XInput mode if it has one, or use a compatible translation layer. XInput's API does not provide a manufacturer's display name, so those devices are listed by controller slot rather than exact model name.

## Build/source

`src/ControllerTestLab.c` is the native source. `Build-Linux.sh` uses Clang and `lld-link` to cross-compile a Windows executable from Linux. The compiled app links only standard Windows system libraries; XInput and WinMM are loaded dynamically so the app can fall back if one API is unavailable.

## Validation note

The file was compiled and its PE header/import table were checked in this environment. This environment is Linux, so I could not launch the Windows GUI or test it against a physical controller here.

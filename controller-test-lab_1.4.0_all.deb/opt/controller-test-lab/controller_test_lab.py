#!/usr/bin/env python3
"""Controller Test Lab for Linux: live Linux evdev gamepad monitor."""
import os
import re
import glob
import struct
import fcntl
import ctypes
import time
import json
import math
import shutil
import tempfile
import threading
import subprocess
import wave
import sys
from array import array
from collections import deque
import tkinter as tk
from tkinter import ttk, messagebox

APP_NAME = "Controller Test Lab"
VERSION = "1.4.0"
# A restrained light palette and a matching dark palette. The accent colors
# remain high-contrast in both modes; theme changes do not alter diagnostic data.
PALETTES = {
    "light": {
        "BG": "#f6f8fb", "PANEL": "#ffffff", "PANEL_2": "#eef2f6",
        "EDGE": "#e0e6ed", "TEXT": "#1e2937", "MUTED": "#697789",
        "CYAN": "#2878e6", "GREEN": "#16865f", "ORANGE": "#b56a10", "RED": "#d43f53",
        "CANVAS": "#f2f5f8", "GRID": "#aeb9c6", "GRID_2": "#e8edf2",
        "BADGE": "#edf1f5", "ACCENT_BG": "#e4efff", "ACCENT_FG": "#174ea6",
        "ACCENT_EDGE": "#b8d5ff", "ACCENT_HOVER": "#dbeafe", "GOOD_BG": "#d7f3e7",
        "BAD_BG": "#fbe2e6", "DOT_BASE": "#c3cdda", "DOT_RING": "#65758a",
        "FIELD_BG": "#f1f6fd", "FIELD_HOVER": "#eaf1fb",
    },
    "dark": {
        "BG": "#10141c", "PANEL": "#191f2a", "PANEL_2": "#222b39",
        "EDGE": "#303b4d", "TEXT": "#e8edf5", "MUTED": "#a1adbd",
        "CYAN": "#78b7ff", "GREEN": "#67d7aa", "ORANGE": "#ffc17d", "RED": "#ff8292",
        "CANVAS": "#131a25", "GRID": "#566477", "GRID_2": "#293344",
        "BADGE": "#252f3e", "ACCENT_BG": "#223957", "ACCENT_FG": "#b8d7ff",
        "ACCENT_EDGE": "#41658f", "ACCENT_HOVER": "#2c4565", "GOOD_BG": "#1b3d33",
        "BAD_BG": "#472b36", "DOT_BASE": "#65758a", "DOT_RING": "#8292a8",
        "FIELD_BG": "#182231", "FIELD_HOVER": "#2a374a",
    },
}

def set_palette(mode):
    global BG, PANEL, PANEL_2, EDGE, TEXT, MUTED, CYAN, GREEN, ORANGE, RED
    global CANVAS, GRID, GRID_2, BADGE, ACCENT_BG, ACCENT_FG, ACCENT_EDGE
    global ACCENT_HOVER, GOOD_BG, BAD_BG, DOT_BASE, DOT_RING, FIELD_BG, FIELD_HOVER
    palette = PALETTES.get(mode, PALETTES["light"])
    for name, value in palette.items():
        globals()[name] = value

set_palette("light")

# Linux input event types / axes / key codes.
EV_SYN, EV_KEY, EV_ABS, EV_FF = 0, 1, 3, 0x15
ABS_X, ABS_Y, ABS_Z, ABS_RX, ABS_RY, ABS_RZ = 0, 1, 2, 3, 4, 5
ABS_THROTTLE, ABS_RUDDER, ABS_WHEEL, ABS_GAS, ABS_BRAKE = 6, 7, 8, 9, 10
ABS_HAT0X, ABS_HAT0Y, ABS_HAT1X, ABS_HAT1Y = 16, 17, 18, 19
BTN_MISC, BTN_JOYSTICK, BTN_GAMEPAD = 0x100, 0x120, 0x130

AXIS_LABELS = {
    ABS_X: "Left stick · X", ABS_Y: "Left stick · Y", ABS_Z: "Axis Z / LT",
    ABS_RX: "Right stick · X", ABS_RY: "Right stick · Y", ABS_RZ: "Axis RZ / RT",
    ABS_THROTTLE: "Throttle", ABS_RUDDER: "Rudder", ABS_WHEEL: "Wheel",
    ABS_GAS: "Gas / RT", ABS_BRAKE: "Brake / LT", ABS_HAT0X: "D-pad · X",
    ABS_HAT0Y: "D-pad · Y", ABS_HAT1X: "D-pad 2 · X", ABS_HAT1Y: "D-pad 2 · Y",
}
BUTTON_LABELS = {
    0x120: "Trigger", 0x121: "Thumb", 0x122: "Thumb 2", 0x123: "Top", 0x124: "Top 2",
    0x125: "Pinkie", 0x126: "Base 1", 0x127: "Base 2", 0x128: "Base 3", 0x129: "Base 4",
    0x12A: "Base 5", 0x12B: "Base 6", 0x12C: "Trigger Happy 1", 0x12D: "Trigger Happy 2",
    0x12E: "Trigger Happy 3", 0x12F: "Trigger Happy 4",
    0x130: "A / South", 0x131: "B / East", 0x132: "C", 0x133: "X / North", 0x134: "Y / West",
    0x135: "Z", 0x136: "TL / LB", 0x137: "TR / RB", 0x138: "TL2 / LT", 0x139: "TR2 / RT",
    0x13A: "Select / View", 0x13B: "Start / Menu", 0x13C: "Mode / Guide",
    0x13D: "Left stick click", 0x13E: "Right stick click", 0x13F: "Extra button",
    0x220: "D-pad Up", 0x221: "D-pad Down", 0x222: "D-pad Left", 0x223: "D-pad Right",
}

# Native Linux input_event is timeval + type/code/value. On 64-bit Linux this is 24 bytes.
EVENT = struct.Struct("@llHHi")
ABSINFO = struct.Struct("@iiiiii")


def ioc_read(typechar, number, size):
    return (2 << 30) | (size << 16) | (ord(typechar) << 8) | number


def ioc_write(typechar, number, size):
    return (1 << 30) | (size << 16) | (ord(typechar) << 8) | number


def bit_is_set(buffer, bit):
    return bit >= 0 and (bit // 8) < len(buffer) and bool(buffer[bit // 8] & (1 << (bit % 8)))


def ioctl_buffer(fd, request, size):
    buf = bytearray(size)
    fcntl.ioctl(fd, request, buf, True)
    return bytes(buf)


class ControllerDevice:
    def __init__(self, path, name, fd, axes, key_codes, abs_info):
        self.path = path
        self.name = name
        self.fd = fd
        self.axes = axes
        self.key_codes = key_codes
        self.abs_info = abs_info
        self.axis_values = {code: info[0] for code, info in abs_info.items()}
        self.pressed = set()
        self.button_events_seen = 0
        self.axis_events_seen = 0

    def close(self):
        try:
            os.close(self.fd)
        except OSError:
            pass

    def range_for(self, code):
        return self.abs_info.get(code, (0, 0, 255, 0, 0, 0))

    def normal(self, code):
        value, lo, hi, *_ = self.range_for(code)
        value = self.axis_values.get(code, value)
        if hi <= lo:
            return 0.5
        return max(0.0, min(1.0, (value - lo) / (hi - lo)))

    def center_percent(self, code):
        return int(round((self.normal(code) - 0.5) * 200))


def find_gamepads():
    devices, denied = [], 0
    keywords = ("gamepad", "game pad", "controller", "joystick", "xbox", "dualshock", "dualsense",
                "playstation", "8bitdo", "switch pro", "joy-con", "stadia", "steam deck", "pro controller")
    for path in sorted(glob.glob("/dev/input/event*")):
        fd = None
        try:
            fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK | getattr(os, "O_CLOEXEC", 0))
            name_buf = ioctl_buffer(fd, ioc_read("E", 0x06, 256), 256)
            name = name_buf.split(b"\0", 1)[0].decode("utf-8", "replace").strip() or path
            ev_bits = ioctl_buffer(fd, ioc_read("E", 0x20 + 0, 8), 8)
            if not bit_is_set(ev_bits, EV_KEY) or not bit_is_set(ev_bits, EV_ABS):
                os.close(fd); continue
            key_bits = ioctl_buffer(fd, ioc_read("E", 0x20 + EV_KEY, 96), 96)
            abs_bits = ioctl_buffer(fd, ioc_read("E", 0x20 + EV_ABS, 16), 16)
            axes = [code for code in range(64) if bit_is_set(abs_bits, code)]
            key_codes = [code for code in range(768) if bit_is_set(key_bits, code)]
            has_xy = ABS_X in axes and ABS_Y in axes
            has_game_buttons = any(BTN_JOYSTICK <= code <= 0x13F or 0x220 <= code <= 0x223 or 0x2C0 <= code <= 0x2E7 for code in key_codes)
            named_gamepad = any(word in name.lower() for word in keywords)
            if not (has_xy and has_game_buttons) and not (named_gamepad and len(axes) >= 2 and len(key_codes) >= 4):
                os.close(fd); continue
            abs_info = {}
            for code in axes:
                try:
                    data = ioctl_buffer(fd, ioc_read("E", 0x40 + code, ABSINFO.size), ABSINFO.size)
                    abs_info[code] = ABSINFO.unpack(data)
                except OSError:
                    abs_info[code] = (0, 0, 255, 0, 0, 0)
            devices.append(ControllerDevice(path, name, fd, axes, key_codes, abs_info))
        except PermissionError:
            denied += 1
            if fd is not None:
                try: os.close(fd)
                except OSError: pass
        except (OSError, ValueError):
            if fd is not None:
                try: os.close(fd)
                except OSError: pass
    return devices, denied


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} · Linux")
        self.geometry("1180x900")
        self.minsize(940, 720)
        self.settings_path = os.path.join(os.path.expanduser("~"), ".config", "controller-test-lab", "settings.json")
        self.settings = self._load_settings()
        self.theme_mode = self.settings.get("theme_mode", "light")
        if self.theme_mode not in PALETTES:
            self.theme_mode = "light"
        set_palette(self.theme_mode)
        self.configure(bg=BG)
        self.magnifying_dots_enabled = bool(self.settings.get("magnifying_dots_enabled", True))
        try:
            self.magnifying_strength = max(0.5, min(2.0, float(self.settings.get("magnifying_strength", 1.25))))
        except (TypeError, ValueError):
            self.magnifying_strength = 1.25
        self.devices = []
        self.selected = None
        self.denied_count = 0
        self.button_widgets = {}
        self.axis_bars = {}
        self.axis_values = {}
        self.rumble_after = None
        # Drift measurements remain raw and deadzone-free. The graph has a selectable scale.
        self.calibration = {}
        self.calibration_active = False
        self.calibration_started = 0.0
        self.calibration_samples = {}
        self.drift_history = {c: deque(maxlen=300) for c in (ABS_X, ABS_Y, ABS_RX, ABS_RY)}
        self.drift_scale = 0.1
        # Audio state
        self.audio_outputs = []
        self.audio_inputs = []
        self.audio_proc = None
        self.audio_thread = None
        self.audio_running = False
        self.audio_level_db = -60.0
        self.audio_error = ""
        self.audio_lock = threading.Lock()
        self.audio_tone_path = None
        self.screen_test_win = None
        self.keyboard_test_win = None
        self.mouse_test_win = None
        self.screen_test_after = None
        self.mic_source_name = None
        self.output_sink_name = None
        self._build_styles()
        self._build_ui()
        self.scan_devices()
        self.scan_audio_devices()
        self.poll_after = self.after(18, self.poll)
        self.audio_meter_after = self.after(45, self.update_audio_meter)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _load_settings(self):
        try:
            with open(self.settings_path, "r", encoding="utf-8") as stream:
                value = json.load(stream)
            return value if isinstance(value, dict) else {}
        except (OSError, ValueError, TypeError):
            return {}

    def _save_settings(self):
        self.settings = {
            "theme_mode": self.theme_mode,
            "magnifying_dots_enabled": bool(self.magnifying_dots_enabled),
            "magnifying_strength": float(self.magnifying_strength),
        }
        try:
            os.makedirs(os.path.dirname(self.settings_path), exist_ok=True)
            temp_path = self.settings_path + ".tmp"
            with open(temp_path, "w", encoding="utf-8") as stream:
                json.dump(self.settings, stream, indent=2)
            os.replace(temp_path, self.settings_path)
        except OSError as exc:
            self.footer.configure(text=f"Settings apply for this session, but could not be saved: {exc}")

    def open_settings(self):
        win = tk.Toplevel(self)
        win.title("Controller Test Lab · Settings")
        win.resizable(False, False)
        win.configure(bg=BG)
        win.transient(self)
        win.grab_set()
        outer = tk.Frame(win, bg=BG, padx=22, pady=20)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="Settings", style="Title.TLabel").pack(anchor="w")
        ttk.Label(outer, text="Tune the controller visualizer.", style="Muted.TLabel").pack(anchor="w", pady=(3, 16))

        card = self._panel(outer, 14)
        card.pack(fill="x")
        ttk.Label(card, text="APPEARANCE", style="PanelMuted.TLabel").pack(anchor="w")
        theme_var = tk.StringVar(value=self.theme_mode)
        theme_row = tk.Frame(card, bg=PANEL)
        theme_row.pack(fill="x", pady=(5, 15))
        ttk.Radiobutton(theme_row, text="Light", value="light", variable=theme_var).pack(side="left", padx=(0, 16))
        ttk.Radiobutton(theme_row, text="Dark", value="dark", variable=theme_var).pack(side="left")
        ttk.Label(card, text="STICK VISUALIZER", style="PanelMuted.TLabel").pack(anchor="w", pady=(0, 5))
        enabled = tk.BooleanVar(value=self.magnifying_dots_enabled)
        ttk.Checkbutton(card, text="Magnifying dot field", variable=enabled).pack(anchor="w")
        tk.Label(card, text="Dots near the live stick position gently enlarge, creating a soft lens effect. Turn this off for a static dot grid.",
                 bg=PANEL, fg=MUTED, justify="left", wraplength=360, font=("DejaVu Sans", 9)).pack(anchor="w", pady=(5, 14))
        ttk.Label(card, text="MAGNIFICATION STRENGTH", style="PanelMuted.TLabel").pack(anchor="w")
        strength = tk.DoubleVar(value=self.magnifying_strength)
        scale = tk.Scale(card, from_=0.5, to=2.0, resolution=0.1, orient="horizontal", variable=strength,
                         bg=PANEL, fg=TEXT, activebackground=CYAN, troughcolor=GRID_2, highlightthickness=0,
                         bd=0, showvalue=True, length=340)
        scale.pack(fill="x", pady=(2, 0))
        preview = tk.Canvas(outer, width=360, height=125, bg=PANEL, bd=0, highlightthickness=1, highlightbackground=EDGE)
        preview.pack(fill="x", pady=(13, 14))
        def redraw_preview(*_args):
            self._draw_stick(preview, 0.69, 0.35, magnify_enabled=enabled.get(), magnification=float(strength.get()))
        enabled.trace_add("write", redraw_preview)
        scale.configure(command=lambda _v: redraw_preview())
        redraw_preview()
        actions = tk.Frame(outer, bg=BG)
        actions.pack(fill="x")
        def save_and_close():
            self.magnifying_dots_enabled = bool(enabled.get())
            self.magnifying_strength = max(0.5, min(2.0, float(strength.get())))
            self.apply_theme(theme_var.get())
            self._save_settings()
            self._redraw_stick_views()
            win.destroy()
        def reset_defaults():
            enabled.set(True)
            strength.set(1.25)
            theme_var.set("light")
            redraw_preview()
        ttk.Button(actions, text="Reset defaults", command=reset_defaults).pack(side="left")
        ttk.Button(actions, text="Cancel", command=win.destroy).pack(side="right", padx=(6, 0))
        ttk.Button(actions, text="Save settings", command=save_and_close, style="Accent.TButton").pack(side="right")
        win.bind("<Escape>", lambda _event: win.destroy())
        win.update_idletasks()
        win.geometry(f"{win.winfo_reqwidth()}x{win.winfo_reqheight()}")
        win.focus_force()

    def _redraw_stick_views(self):
        dev = self.selected
        if not dev:
            self._draw_stick(self.left_canvas, 0.5, 0.5)
            self._draw_stick(self.right_canvas, 0.5, 0.5)
            return
        self._draw_stick(self.left_canvas, dev.normal(ABS_X), dev.normal(ABS_Y))
        self._draw_stick(self.right_canvas, dev.normal(ABS_RX) if ABS_RX in dev.axes else 0.5,
                         dev.normal(ABS_RY) if ABS_RY in dev.axes else 0.5)

    def _build_styles(self):
        s = ttk.Style(self)
        try: s.theme_use("clam")
        except tk.TclError: pass
        s.configure("TFrame", background=BG)
        s.configure("Panel.TFrame", background=PANEL)
        s.configure("TLabel", background=BG, foreground=TEXT, font=("DejaVu Sans", 10))
        s.configure("Muted.TLabel", background=BG, foreground=MUTED, font=("DejaVu Sans", 9))
        s.configure("Panel.TLabel", background=PANEL, foreground=TEXT, font=("DejaVu Sans", 10))
        s.configure("PanelMuted.TLabel", background=PANEL, foreground=MUTED, font=("DejaVu Sans", 9))
        s.configure("Title.TLabel", background=BG, foreground=TEXT, font=("DejaVu Sans", 22, "bold"))
        s.configure("Section.TLabel", background=PANEL, foreground=TEXT, font=("DejaVu Sans", 11, "bold"))
        s.configure("TButton", background=PANEL, foreground=TEXT, bordercolor=EDGE, padding=(12, 8), font=("DejaVu Sans", 9))
        s.map("TButton", background=[("active", FIELD_HOVER), ("disabled", PANEL)], foreground=[("disabled", MUTED)])
        s.configure("Accent.TButton", background=ACCENT_BG, foreground=ACCENT_FG, bordercolor=ACCENT_EDGE)
        s.map("Accent.TButton", background=[("active", ACCENT_HOVER)])
        s.configure("TCombobox", fieldbackground=PANEL, background=PANEL, foreground=TEXT, arrowcolor=CYAN,
                    bordercolor=EDGE, lightcolor=EDGE, darkcolor=EDGE, padding=7)
        s.map("TCombobox", fieldbackground=[("readonly", PANEL)], foreground=[("readonly", TEXT)])
        s.configure("Horizontal.TProgressbar", troughcolor=GRID_2, background=CYAN, bordercolor=GRID_2, lightcolor=CYAN, darkcolor=CYAN)
        s.configure("TNotebook", background=BG, borderwidth=0, bordercolor=EDGE, lightcolor=BG, darkcolor=EDGE, relief="flat")
        s.configure("TNotebook.Tab", background=BADGE, foreground=MUTED, bordercolor=EDGE,
                    lightcolor=EDGE, darkcolor=EDGE, padding=(20, 10), font=("DejaVu Sans", 9, "bold"))
        s.map("TNotebook.Tab", background=[("selected", PANEL)], foreground=[("selected", CYAN)])
        s.configure("TRadiobutton", background=PANEL, foreground=TEXT, font=("DejaVu Sans", 9))
        s.map("TRadiobutton", background=[("active", PANEL)], foreground=[("disabled", MUTED)])
        s.configure("TCheckbutton", background=PANEL, foreground=TEXT, font=("DejaVu Sans", 9))
        s.map("TCheckbutton", background=[("active", PANEL)], foreground=[("disabled", MUTED)])

    def apply_theme(self, mode):
        """Apply a cohesive theme to the existing UI without rebuilding diagnostics."""
        if mode not in PALETTES:
            mode = "light"
        old_mode = self.theme_mode
        if mode == old_mode:
            # Still refresh widgets whose theme-specific canvas colors are drawn dynamically.
            self._build_styles()
            self._redraw_stick_views()
            self._draw_drift_graph()
            self._draw_mic_meter()
            return
        old = PALETTES[old_mode]
        new = PALETTES[mode]
        color_map = {old[key]: new[key] for key in old.keys()}
        # Semantic aliases used by earlier versions of the UI.
        color_map.update({
            "#e3e8ef": new["GRID_2"], "#eaf1fb": new["FIELD_HOVER"],
            "#e4efff": new["ACCENT_BG"], "#174ea6": new["ACCENT_FG"],
            "#b8d5ff": new["ACCENT_EDGE"], "#dbeafe": new["ACCENT_HOVER"],
            "#edf1f5": new["BADGE"], "#f2f5f8": new["CANVAS"],
            "#d7f3e7": new["GOOD_BG"], "#fbe2e6": new["BAD_BG"],
            "#dceaff": new["ACCENT_BG"], "#91b8f5": new["ACCENT_EDGE"],
            "#cfd8e4": new["EDGE"], "#f1f6fd": new["FIELD_BG"],
            "#f0f3f7": new["GRID_2"], "#e6ebf2": new["GRID_2"],
            "#edf1f6": new["GRID_2"], "#aeb9c6": new["GRID"],
            "#e8edf2": new["GRID_2"], "#a9b5c4": new["GRID"],
            "#9aa8b8": new["MUTED"], "#65758a": new["DOT_RING"],
        })
        self.theme_mode = mode
        set_palette(mode)
        self.configure(bg=BG)
        self._build_styles()

        def recolor(widget):
            try:
                keys = set(widget.keys())
                changes = {}
                for opt in ("bg", "background", "fg", "foreground", "highlightbackground", "highlightcolor",
                            "insertbackground", "troughcolor", "activebackground", "selectbackground", "selectforeground"):
                    if opt in keys:
                        try:
                            value = widget.cget(opt)
                            if isinstance(value, str) and value.lower() in color_map:
                                changes[opt] = color_map[value.lower()]
                        except (tk.TclError, TypeError):
                            pass
                if changes:
                    widget.configure(**changes)
            except tk.TclError:
                pass
            try:
                for child in widget.winfo_children():
                    recolor(child)
            except tk.TclError:
                pass

        recolor(self)
        self.configure(bg=BG)
        # Canvas drawings are recreated using the active palette.
        self._redraw_stick_views()
        self._draw_drift_graph()
        self._draw_mic_meter()
        if hasattr(self, "footer"):
            self.footer.configure(bg=BG, fg=MUTED)

    def _panel(self, parent, padding=14):
        return tk.Frame(parent, bg=PANEL, highlightbackground=EDGE, highlightthickness=1, padx=padding, pady=padding)

    def _build_ui(self):
        # Quiet, compact header
        header = tk.Frame(self, bg=BG, padx=22, pady=15)
        header.pack(fill="x")
        title_row = tk.Frame(header, bg=BG); title_row.pack(fill="x")
        ttk.Label(title_row, text="Controller Test Lab", style="Title.TLabel").pack(side="left")
        self.header_badge = tk.Label(title_row, text="LINUX  ·  v" + VERSION, bg=PANEL_2, fg=MUTED,
                                     padx=10, pady=5, font=("DejaVu Sans", 8, "bold"))
        self.header_badge.pack(side="right")
        self.settings_button = ttk.Button(title_row, text="Settings  ⚙", command=self.open_settings)
        self.settings_button.pack(side="right", padx=(0, 9))
        ttk.Label(header, text="Controller · audio · display · input diagnostics", style="Muted.TLabel").pack(anchor="w", pady=(3, 0))

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=18, pady=(0, 8))
        self.controller_tab = tk.Frame(self.tabs, bg=BG, padx=12, pady=12)
        self.audio_tab = tk.Frame(self.tabs, bg=BG, padx=12, pady=12)
        self.tools_tab = tk.Frame(self.tabs, bg=BG, padx=12, pady=12)
        self.tabs.add(self.controller_tab, text="  Controller  ")
        self.tabs.add(self.audio_tab, text="  Audio devices  ")
        self.tabs.add(self.tools_tab, text="  Screen & input  ")
        self._build_controller_tab()
        self._build_audio_tab()
        self._build_tools_tab()
        self.footer = tk.Label(self, text="Ready · scans devices locally; mic audio is not saved.", bg=BG, fg=MUTED,
                               anchor="w", padx=23, pady=8, font=("DejaVu Sans", 8))
        self.footer.pack(fill="x", side="bottom")

    def _build_controller_tab(self):
        # Device selector
        device_card = self._panel(self.controller_tab, 12)
        device_card.pack(fill="x", pady=(0, 10))
        left = tk.Frame(device_card, bg=PANEL); left.pack(side="left", fill="x", expand=True)
        ttk.Label(left, text="CONTROLLER", style="PanelMuted.TLabel").pack(anchor="w")
        self.device_combo = ttk.Combobox(left, state="readonly", width=45)
        self.device_combo.pack(fill="x", pady=(5, 0))
        self.device_combo.bind("<<ComboboxSelected>>", self.change_device)
        self.path_label = tk.Label(device_card, text="No device selected", bg=PANEL, fg=MUTED,
                                    justify="left", anchor="w", font=("DejaVu Sans", 8))
        self.path_label.pack(side="left", padx=18, fill="x", expand=True)
        self.rescan_button = ttk.Button(device_card, text="Rescan", command=self.scan_devices, style="Accent.TButton")
        self.rescan_button.pack(side="right")
        self.status = tk.Label(self.controller_tab, text="Searching for controllers…", bg=BG, fg=ORANGE,
                               anchor="w", font=("DejaVu Sans", 9))
        self.status.pack(fill="x", pady=(0, 10))

        sticks_row = tk.Frame(self.controller_tab, bg=BG)
        sticks_row.pack(fill="x", pady=(0, 10))
        left_card = self._panel(sticks_row, 11); left_card.pack(side="left", fill="both", expand=True, padx=(0, 5))
        right_card = self._panel(sticks_row, 11); right_card.pack(side="left", fill="both", expand=True, padx=(5, 0))
        for card, title in ((left_card, "LEFT STICK"), (right_card, "RIGHT STICK")):
            ttk.Label(card, text=title, style="Section.TLabel").pack(anchor="w")
            ttk.Label(card, text="Nearby dots enlarge around the live position", style="PanelMuted.TLabel").pack(anchor="w", pady=(2, 0))
        self.left_canvas = tk.Canvas(left_card, width=210, height=128, bg=PANEL, bd=0, highlightthickness=0)
        self.left_canvas.pack(fill="x", pady=(5, 2))
        self.left_offset = tk.Label(left_card, text="Center offset  X +0.0000%  ·  Y +0.0000%", bg=PANEL, fg=CYAN,
                                    font=("DejaVu Sans Mono", 8), anchor="center")
        self.left_offset.pack(fill="x", pady=(1, 3))
        self.left_baseline = tk.Label(left_card, text="Baseline delta  X —  ·  Y —", bg=PANEL, fg=MUTED,
                                      font=("DejaVu Sans Mono", 8), anchor="center")
        self.left_baseline.pack(fill="x")
        self.left_peak = tk.Label(left_card, text="5 s movement peak  X —  ·  Y —", bg=PANEL, fg=MUTED,
                                  font=("DejaVu Sans Mono", 8), anchor="center")
        self.left_peak.pack(fill="x", pady=(3, 0))
        self.right_canvas = tk.Canvas(right_card, width=210, height=128, bg=PANEL, bd=0, highlightthickness=0)
        self.right_canvas.pack(fill="x", pady=(5, 2))
        self.right_offset = tk.Label(right_card, text="Center offset  X +0.0000%  ·  Y +0.0000%", bg=PANEL, fg=CYAN,
                                     font=("DejaVu Sans Mono", 8), anchor="center")
        self.right_offset.pack(fill="x", pady=(1, 3))
        self.right_baseline = tk.Label(right_card, text="Baseline delta  X —  ·  Y —", bg=PANEL, fg=MUTED,
                                       font=("DejaVu Sans Mono", 8), anchor="center")
        self.right_baseline.pack(fill="x")
        self.right_peak = tk.Label(right_card, text="5 s movement peak  X —  ·  Y —", bg=PANEL, fg=MUTED,
                                   font=("DejaVu Sans Mono", 8), anchor="center")
        self.right_peak.pack(fill="x", pady=(3, 0))

        drift = self._panel(self.controller_tab, 11); drift.pack(fill="x", pady=(0, 10))
        dh = tk.Frame(drift, bg=PANEL); dh.pack(fill="x")
        ttk.Label(dh, text="Micro-drift monitor", style="Section.TLabel").pack(side="left")
        ttk.Label(dh, text="No deadzone · raw deltas preserved", style="PanelMuted.TLabel").pack(side="left", padx=(10, 0))
        self.scale_combo = ttk.Combobox(dh, state="readonly", width=12, values=("±1.000%", "±0.100%", "±0.010%", "±0.001%"))
        self.scale_combo.current(1); self.scale_combo.pack(side="right", padx=(8, 0))
        self.scale_combo.bind("<<ComboboxSelected>>", self.change_drift_scale)
        ttk.Button(dh, text="Calibrate resting position", command=self.start_calibration, style="Accent.TButton").pack(side="right")
        self.drift_canvas = tk.Canvas(drift, height=76, bg=CANVAS, bd=0, highlightthickness=0)
        self.drift_canvas.pack(fill="x", pady=(10, 4))
        self.calibration_status = tk.Label(drift, text="Graph shows center offset. Leave sticks untouched and calibrate to measure micro-movement from your resting position.",
                                           bg=PANEL, fg=MUTED, anchor="w", font=("DejaVu Sans", 8))
        self.calibration_status.pack(fill="x")

        lower = tk.Frame(self.controller_tab, bg=BG); lower.pack(fill="both", expand=True)
        axes_card = self._panel(lower, 11); axes_card.pack(side="left", fill="both", expand=True, padx=(0, 5))
        ttk.Label(axes_card, text="Analog inputs", style="Section.TLabel").pack(anchor="w")
        self.axes_area = tk.Frame(axes_card, bg=PANEL); self.axes_area.pack(fill="both", expand=True, pady=(9, 0))
        buttons_card = self._panel(lower, 11); buttons_card.pack(side="left", fill="both", expand=True, padx=(5, 0))
        bhead = tk.Frame(buttons_card, bg=PANEL); bhead.pack(fill="x")
        ttk.Label(bhead, text="Buttons & D-pad", style="Section.TLabel").pack(side="left")
        self.live_badge = tk.Label(bhead, text="WAITING", bg=BADGE, fg=ORANGE, padx=8, pady=3, font=("DejaVu Sans", 8, "bold"))
        self.live_badge.pack(side="right")
        self.buttons_grid = tk.Frame(buttons_card, bg=PANEL); self.buttons_grid.pack(fill="both", expand=True, pady=(9, 0))
        self.dpad_label = tk.Label(buttons_card, text="D-pad centered", bg=PANEL_2, fg=MUTED, padx=10, pady=7, font=("DejaVu Sans", 8))
        self.dpad_label.pack(fill="x", pady=(8, 0))
        rumble_row = tk.Frame(buttons_card, bg=PANEL); rumble_row.pack(fill="x", pady=(8, 0))
        ttk.Label(rumble_row, text="Haptics", style="PanelMuted.TLabel").pack(side="left")
        self.rumble_button = ttk.Button(rumble_row, text="Test vibration", command=self.test_rumble)
        self.rumble_button.pack(side="right")
        self._draw_stick(self.left_canvas, .5, .5)
        self._draw_stick(self.right_canvas, .5, .5)
        self._draw_drift_graph()
        self._show_no_controller("Connect a gamepad, then select Rescan.")

    def _build_audio_tab(self):
        intro = tk.Label(self.audio_tab, text="Find sound devices and verify each path. Microphone monitoring is live-only; no audio is recorded to disk.",
                         bg=BG, fg=MUTED, anchor="w", justify="left", wraplength=900, font=("DejaVu Sans", 9))
        intro.pack(fill="x", pady=(0, 12))
        grid = tk.Frame(self.audio_tab, bg=BG); grid.pack(fill="both", expand=True)
        outputs = self._panel(grid, 16); outputs.pack(side="left", fill="both", expand=True, padx=(0, 6))
        inputs = self._panel(grid, 16); inputs.pack(side="left", fill="both", expand=True, padx=(6, 0))
        oh = tk.Frame(outputs, bg=PANEL); oh.pack(fill="x")
        ttk.Label(oh, text="Speakers & outputs", style="Section.TLabel").pack(side="left")
        ttk.Button(oh, text="Scan", command=self.scan_audio_devices).pack(side="right")
        ttk.Label(outputs, text="Output device", style="PanelMuted.TLabel").pack(anchor="w", pady=(18, 5))
        self.output_combo = ttk.Combobox(outputs, state="readonly")
        self.output_combo.pack(fill="x")
        self.output_combo.bind("<<ComboboxSelected>>", self.change_output)
        self.output_details = tk.Label(outputs, text="Scanning audio outputs…", bg=PANEL, fg=MUTED, anchor="nw", justify="left",
                                       wraplength=360, font=("DejaVu Sans", 9))
        self.output_details.pack(fill="x", pady=(13, 16))
        ttk.Button(outputs, text="Play test tone", command=self.test_speaker, style="Accent.TButton").pack(anchor="w")
        self.speaker_status = tk.Label(outputs, text="A short 440 Hz tone checks the selected output.", bg=PANEL, fg=MUTED,
                                       anchor="w", justify="left", wraplength=360, font=("DejaVu Sans", 8))
        self.speaker_status.pack(fill="x", pady=(12, 0))

        ih = tk.Frame(inputs, bg=PANEL); ih.pack(fill="x")
        ttk.Label(ih, text="Microphones & inputs", style="Section.TLabel").pack(side="left")
        ttk.Button(ih, text="Scan", command=self.scan_audio_devices).pack(side="right")
        ttk.Label(inputs, text="Input device", style="PanelMuted.TLabel").pack(anchor="w", pady=(18, 5))
        self.mic_combo = ttk.Combobox(inputs, state="readonly")
        self.mic_combo.pack(fill="x")
        self.mic_combo.bind("<<ComboboxSelected>>", self.change_mic)
        self.input_details = tk.Label(inputs, text="Scanning audio inputs…", bg=PANEL, fg=MUTED, anchor="nw", justify="left",
                                      wraplength=360, font=("DejaVu Sans", 9))
        self.input_details.pack(fill="x", pady=(13, 16))
        self.mic_meter = tk.Canvas(inputs, height=26, bg=CANVAS, bd=0, highlightthickness=0)
        self.mic_meter.pack(fill="x", pady=(0, 10))
        self.mic_meter.bind("<Configure>", lambda _e: self._draw_mic_meter())
        self.mic_status = tk.Label(inputs, text="Mic monitor is off.", bg=PANEL, fg=MUTED, anchor="w", font=("DejaVu Sans", 8))
        self.mic_status.pack(fill="x", pady=(0, 12))
        self.mic_button = ttk.Button(inputs, text="Start microphone test", command=self.toggle_mic_test, style="Accent.TButton")
        self.mic_button.pack(anchor="w")

        bottom = self._panel(self.audio_tab, 14); bottom.pack(fill="x", pady=(12, 0))
        ttk.Label(bottom, text="Device discovery", style="Section.TLabel").pack(anchor="w")
        self.audio_summary = tk.Label(bottom, text="Uses PipeWire/PulseAudio when available, with ALSA fallback for discovery and playback.",
                                      bg=PANEL, fg=MUTED, anchor="w", justify="left", wraplength=920, font=("DejaVu Sans", 8))
        self.audio_summary.pack(fill="x", pady=(7, 0))

    # ----- Screen, keyboard, and mouse diagnostics -----
    def _build_tools_tab(self):
        intro = tk.Label(self.tools_tab,
            text="Quick hardware checks for your display and input devices. Screen patterns are visual-assisted: inspect the panel for stuck/dead pixels, banding or unevenness.",
            bg=BG, fg=MUTED, anchor="w", justify="left", wraplength=1000,
            font=("DejaVu Sans", 9))
        intro.pack(fill="x", pady=(0, 14))

        display = self._panel(self.tools_tab, 18)
        display.pack(fill="x", pady=(0, 10))
        top = tk.Frame(display, bg=PANEL); top.pack(fill="x")
        ttk.Label(top, text="Display diagnostics", style="Section.TLabel").pack(side="left")
        ttk.Button(top, text="Refresh display info", command=self.refresh_display_info).pack(side="right")
        self.screen_info_label = tk.Label(display, text="Reading display information…", bg=PANEL, fg=MUTED,
            anchor="w", justify="left", font=("DejaVu Sans", 9))
        self.screen_info_label.pack(fill="x", pady=(7, 12))
        display_buttons = tk.Frame(display, bg=PANEL); display_buttons.pack(fill="x")
        ttk.Button(display_buttons, text="Dead / stuck pixel check", command=self.start_screen_test, style="Accent.TButton").pack(side="left", padx=(0, 7))
        ttk.Button(display_buttons, text="Gradient & color banding", command=lambda: self.start_screen_test(9)).pack(side="left", padx=7)
        ttk.Button(display_buttons, text="Motion / ghosting", command=lambda: self.start_screen_test(14)).pack(side="left", padx=7)
        tk.Label(display, text="Fullscreen controls: ← / → or Space to change pattern · H hides help · Esc exits · click to advance.",
                 bg=PANEL, fg=MUTED, anchor="w", font=("DejaVu Sans", 8)).pack(fill="x", pady=(12, 0))

        row = tk.Frame(self.tools_tab, bg=BG); row.pack(fill="both", expand=True)
        keycard = self._panel(row, 18); keycard.pack(side="left", fill="both", expand=True, padx=(0, 6))
        mousecard = self._panel(row, 18); mousecard.pack(side="left", fill="both", expand=True, padx=(6, 0))
        kh = tk.Frame(keycard, bg=PANEL); kh.pack(fill="x")
        ttk.Label(kh, text="Keyboard tester", style="Section.TLabel").pack(side="left")
        ttk.Button(kh, text="Open tester", command=self.start_keyboard_test, style="Accent.TButton").pack(side="right")
        tk.Label(keycard, text="Check key presses, releases, modifiers, arrows, and stuck keys. A pressed key lights up while held.",
                 bg=PANEL, fg=MUTED, justify="left", anchor="w", wraplength=430, font=("DejaVu Sans", 9)).pack(fill="x", pady=(12, 0))
        tk.Label(keycard, text="Mouse & scroll tester", bg=PANEL, fg=TEXT, font=("DejaVu Sans", 11, "bold")).pack(anchor="w", pady=(24, 0))
        tk.Label(keycard, text="Track cursor movement, button clicks, wheel directions, and simple event-rate estimates.",
                 bg=PANEL, fg=MUTED, justify="left", anchor="w", wraplength=430, font=("DejaVu Sans", 9)).pack(fill="x", pady=(7, 10))
        ttk.Button(keycard, text="Open mouse tester", command=self.start_mouse_test).pack(anchor="w")

        misc = tk.Frame(mousecard, bg=PANEL); misc.pack(fill="x")
        ttk.Label(misc, text="Other quick checks", style="Section.TLabel").pack(anchor="w")
        actions = [
            ("Scan controllers", self.scan_devices),
            ("Scan speakers & microphones", self.scan_audio_devices),
            ("Open screen patterns", self.start_screen_test),
        ]
        for label, command in actions:
            ttk.Button(misc, text=label, command=command).pack(fill="x", pady=(10, 0))
        tk.Label(mousecard, text="Privacy", bg=PANEL, fg=TEXT, font=("DejaVu Sans", 11, "bold")).pack(anchor="w", pady=(24, 0))
        tk.Label(mousecard, text="Tests run locally. The mic meter is not recorded. Screen tests only display patterns; you inspect the panel yourself. No network scan or telemetry is used.",
                 bg=PANEL, fg=MUTED, justify="left", anchor="w", wraplength=430, font=("DejaVu Sans", 9)).pack(fill="x", pady=(7, 0))
        self.refresh_display_info()

    def refresh_display_info(self):
        if not hasattr(self, "screen_info_label"):
            return
        lines = []
        xrandr = self._run_quiet(["xrandr", "--current"], timeout=3) if shutil.which("xrandr") else None
        if xrandr and xrandr.returncode == 0:
            for line in xrandr.stdout.splitlines():
                if " connected" in line:
                    name = line.split()[0]
                    mode = ""
                    match = re.search(r"(\d{3,5}x\d{3,5})\+\d+\+\d+", line)
                    if match: mode = match.group(1)
                    else:
                        # Current mode is usually the starred mode listed below the connected row.
                        pass
                    lines.append(f"Display: {name}" + (f"  ·  {mode}" if mode else ""))
        if not lines:
            lines.append("Display info: desktop display server did not expose xrandr data.")
        lines.append(f"Session: {os.environ.get('XDG_SESSION_TYPE', 'unknown')}  ·  Desktop: {os.environ.get('XDG_CURRENT_DESKTOP', 'unknown')}")
        self.screen_info_label.configure(text="\n".join(lines))

    def start_screen_test(self, start_index=0):
        if self.screen_test_win and self.screen_test_win.winfo_exists():
            self.screen_test_win.destroy()
        win = tk.Toplevel(self)
        self.screen_test_win = win
        win.title("Controller Test Lab · Display check")
        win.configure(bg="#000000")
        fullscreen = [True]
        # Some lightweight/virtual window managers ignore Tk's fullscreen hint.
        # Explicit screen geometry plus an undecorated window gives a reliable
        # borderless test surface across Cinnamon, Xfce, GNOME and Xvfb.
        try: win.attributes("-fullscreen", True)
        except tk.TclError: pass
        try: win.overrideredirect(True)
        except tk.TclError: pass
        sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
        win.geometry(f"{sw}x{sh}+0+0")
        win.lift()
        canvas = tk.Canvas(win, bg="#000000", highlightthickness=0, bd=0, cursor="none")
        canvas.pack(fill="both", expand=True)
        self._screen_patterns = [
            ("Black", "solid", "#000000"), ("White", "solid", "#ffffff"),
            ("Red", "solid", "#ff0000"), ("Green", "solid", "#00ff00"), ("Blue", "solid", "#0000ff"),
            ("Cyan", "solid", "#00ffff"), ("Magenta", "solid", "#ff00ff"), ("Yellow", "solid", "#ffff00"),
            ("50% gray", "solid", "#808080"), ("Grayscale gradient", "gray_gradient", ""),
            ("RGB gradients", "rgb_gradient", ""), ("Alignment grid", "grid", ""),
            ("Checkerboard", "checker", ""), ("Color bars", "bars", ""), ("Motion / ghosting", "motion", ""),
        ]
        index = [max(0, min(len(self._screen_patterns)-1, int(start_index)))]
        help_visible = [True]
        motion = {"x": 0, "direction": 1}

        def draw(_event=None):
            if not win.winfo_exists(): return
            canvas.delete("all")
            w = max(1, canvas.winfo_width()); h = max(1, canvas.winfo_height())
            name, kind, value = self._screen_patterns[index[0]]
            if kind == "solid":
                canvas.configure(bg=value)
            else:
                canvas.configure(bg="#ffffff")
                if kind == "gray_gradient":
                    bands = min(512, max(256, w))
                    for i in range(bands):
                        shade = int(i * 255 / max(1, bands-1)); col = f"#{shade:02x}{shade:02x}{shade:02x}"
                        x0 = i*w/bands; x1 = (i+1)*w/bands+1
                        canvas.create_rectangle(x0, 0, x1, h, fill=col, outline=col)
                elif kind == "rgb_gradient":
                    band_h = h/3
                    for row, channel in enumerate((0, 1, 2)):
                        y0=row*band_h; y1=(row+1)*band_h
                        for i in range(256):
                            v=i
                            rgb=[0,0,0]; rgb[channel]=v
                            col="#{:02x}{:02x}{:02x}".format(*rgb)
                            x0=i*w/256; x1=(i+1)*w/256+1
                            canvas.create_rectangle(x0,y0,x1,y1,fill=col,outline=col)
                elif kind == "grid":
                    canvas.configure(bg="#ffffff")
                    for x in range(0, w, max(12, w//80)):
                        canvas.create_line(x,0,x,h,fill="#b8c2ce",width=1)
                    for y in range(0, h, max(12, h//45)):
                        canvas.create_line(0,y,w,y,fill="#b8c2ce",width=1)
                    canvas.create_line(w/2,0,w/2,h,fill="#e63946",width=2)
                    canvas.create_line(0,h/2,w,h/2,fill="#e63946",width=2)
                    rr=min(w,h)*.22
                    canvas.create_oval(w/2-rr,h/2-rr,w/2+rr,h/2+rr,outline="#16865f",width=2)
                elif kind == "checker":
                    size=max(4,min(48,min(w,h)//22))
                    for y in range(0,h,size):
                        for x in range(0,w,size):
                            color="#111111" if ((x//size)+(y//size))%2 else "#ffffff"
                            canvas.create_rectangle(x,y,x+size,y+size,fill=color,outline=color)
                elif kind == "bars":
                    colors=["#ffffff","#ffff00","#00ffff","#00ff00","#ff00ff","#ff0000","#0000ff"]
                    for i,col in enumerate(colors):
                        canvas.create_rectangle(i*w/len(colors),0,(i+1)*w/len(colors)+1,h,fill=col,outline=col)
                elif kind == "motion":
                    canvas.configure(bg="#333333")
                    for xx in range(0,w,80):
                        canvas.create_line(xx,0,xx,h,fill="#484848")
                    canvas.create_oval(w/2-3,h/2-3,w/2+3,h/2+3,fill="#777777",outline="")
                    side=max(24,min(100,h//12))
                    x=max(0,min(w-side,motion["x"]))
                    canvas.create_rectangle(x,h/2-side/2,x+side,h/2+side/2,fill="#ffffff",outline="")
            if help_visible[0]:
                is_light = kind in ("solid",) and value in ("#ffffff", "#ffff00", "#00ffff")
                fg = "#161c25" if is_light else "#ffffff"
                bg = "#ffffff" if is_light else "#151b25"
                panel = tk.Frame(canvas, bg=bg, padx=15, pady=10, highlightbackground="#9aa7b6", highlightthickness=1)
                title = tk.Label(panel, text=f"{index[0]+1:02d} / {len(self._screen_patterns):02d}   {name}", bg=bg, fg=fg, font=("DejaVu Sans", 12, "bold"))
                title.pack(anchor="w")
                sub = tk.Label(panel, text="← → / Space: next   ·   H: hide help   ·   Esc: close", bg=bg, fg=fg, font=("DejaVu Sans", 9))
                sub.pack(anchor="w", pady=(4,0))
                canvas.create_window(20,20,anchor="nw",window=panel)
            if kind == "motion":
                self.screen_test_after = self.after(16, animate_motion)

        def animate_motion():
            if not win.winfo_exists() or index[0] != 14: return
            w=max(1,canvas.winfo_width()); size=max(24,min(100,canvas.winfo_height()//12))
            motion["x"] += motion["direction"] * max(3, w//300)
            if motion["x"] >= w-size: motion["x"]=w-size; motion["direction"]=-1
            elif motion["x"] <= 0: motion["x"]=0; motion["direction"]=1
            draw()

        def go(delta):
            index[0]=(index[0]+delta)%len(self._screen_patterns)
            if self.screen_test_after:
                try: self.after_cancel(self.screen_test_after)
                except Exception: pass
                self.screen_test_after=None
            draw()

        def on_key(event):
            key=event.keysym.lower()
            if key in ("escape",): close(); return "break"
            if key in ("right", "space", "return", "down"): go(1); return "break"
            if key in ("left", "backspace", "up"): go(-1); return "break"
            if key == "h": help_visible[0]=not help_visible[0]; draw(); return "break"
            if key == "f":
                fullscreen[0] = not fullscreen[0]
                try:
                    win.attributes("-fullscreen", fullscreen[0])
                    if fullscreen[0]:
                        win.overrideredirect(True)
                        win.geometry(f"{win.winfo_screenwidth()}x{win.winfo_screenheight()}+0+0")
                    else:
                        win.overrideredirect(False)
                        ww, hh = int(win.winfo_screenwidth() * .8), int(win.winfo_screenheight() * .8)
                        win.geometry(f"{ww}x{hh}+{(win.winfo_screenwidth()-ww)//2}+{(win.winfo_screenheight()-hh)//2}")
                except tk.TclError: pass
                return "break"
        def close():
            if self.screen_test_after:
                try: self.after_cancel(self.screen_test_after)
                except Exception: pass
                self.screen_test_after=None
            if win.winfo_exists(): win.destroy()
            self.screen_test_win=None
        canvas.bind("<Button-1>", lambda _e: go(1))
        win.bind("<KeyPress>", on_key)
        win.protocol("WM_DELETE_WINDOW", close)
        win.after(60, draw)
        win.focus_force()

    def start_keyboard_test(self):
        if self.keyboard_test_win and self.keyboard_test_win.winfo_exists():
            self.keyboard_test_win.lift(); self.keyboard_test_win.focus_force(); return
        win=tk.Toplevel(self); self.keyboard_test_win=win
        win.title("Controller Test Lab · Keyboard tester"); win.geometry("760x560"); win.minsize(600,460); win.configure(bg=BG)
        win.protocol("WM_DELETE_WINDOW", lambda: (setattr(self, "keyboard_test_win", None), win.destroy()))
        wrap=tk.Frame(win,bg=BG,padx=22,pady=20); wrap.pack(fill="both",expand=True)
        tk.Label(wrap,text="Keyboard tester",bg=BG,fg=TEXT,font=("DejaVu Sans",20,"bold")).pack(anchor="w")
        tk.Label(wrap,text="Focus this window, then press and release keys. Indicators remain lit only while a key is held.",bg=BG,fg=MUTED,font=("DejaVu Sans",9)).pack(anchor="w",pady=(4,16))
        stats=tk.Frame(wrap,bg=PANEL,highlightbackground=EDGE,highlightthickness=1,padx=14,pady=12); stats.pack(fill="x")
        keynow=tk.Label(stats,text="No key pressed",bg=PANEL,fg=CYAN,font=("DejaVu Sans Mono",12,"bold")); keynow.pack(anchor="w")
        keymeta=tk.Label(stats,text="Key symbol: —   ·   Key code: —   ·   Presses: 0",bg=PANEL,fg=MUTED,font=("DejaVu Sans Mono",9)); keymeta.pack(anchor="w",pady=(6,0))
        board=tk.Frame(wrap,bg=BG); board.pack(fill="x",pady=16)
        keys=[list("1234567890"),list("QWERTYUIOP"),list("ASDFGHJKL"),list("ZXCVBNM")]
        tiles={}; pressed=set(); count=[0]; events=deque(maxlen=9)
        for r,rowkeys in enumerate(keys):
            line=tk.Frame(board,bg=BG); line.pack(anchor="center",pady=3)
            for key in rowkeys:
                tile=tk.Label(line,text=key,bg=PANEL,fg=MUTED,width=4,pady=8,relief="flat",highlightbackground=EDGE,highlightthickness=1,font=("DejaVu Sans",9,"bold"))
                tile.pack(side="left",padx=2); tiles[key.lower()]=tile
        special=tk.Frame(board,bg=BG); special.pack(anchor="center",pady=3)
        for key,label,width in [("Shift_L","SHIFT",8),("Control_L","CTRL",7),("Alt_L","ALT",6),("space","SPACE",18),("Return","ENTER",8),("BackSpace","BACKSPACE",11),("Left","←",4),("Up","↑",4),("Down","↓",4),("Right","→",4)]:
            tile=tk.Label(special,text=label,bg=PANEL,fg=MUTED,width=width,pady=8,relief="flat",highlightbackground=EDGE,highlightthickness=1,font=("DejaVu Sans",8,"bold"))
            tile.pack(side="left",padx=2); tiles[key.lower()]=tile
        recent=tk.Label(wrap,text="Recent keys: —",bg=BG,fg=MUTED,anchor="w",font=("DejaVu Sans Mono",9)); recent.pack(fill="x",pady=(8,0))
        def press(e):
            key=e.keysym.lower(); pressed.add(key); count[0]+=1; events.appendleft(f"{e.keysym} ({e.keycode})")
            keynow.configure(text=f"Pressed: {e.keysym}",fg=CYAN)
            keymeta.configure(text=f"Key symbol: {e.keysym}   ·   Key code: {e.keycode}   ·   Presses: {count[0]}")
            if key in tiles: tiles[key].configure(bg=ACCENT_BG,fg=ACCENT_FG,highlightbackground=ACCENT_EDGE)
            recent.configure(text="Recent keys: " + "  ·  ".join(events))
        def release(e):
            key=e.keysym.lower(); pressed.discard(key)
            if key in tiles: tiles[key].configure(bg=PANEL,fg=MUTED,highlightbackground=EDGE)
            if not pressed: keynow.configure(text="No key pressed",fg=MUTED)
        win.bind("<KeyPress>",press); win.bind("<KeyRelease>",release)
        win.bind("<FocusOut>",lambda _e: (pressed.clear(), [t.configure(bg=PANEL,fg=MUTED,highlightbackground=EDGE) for t in tiles.values()]))
        win.focus_force()

    def start_mouse_test(self):
        if self.mouse_test_win and self.mouse_test_win.winfo_exists():
            self.mouse_test_win.lift(); self.mouse_test_win.focus_force(); return
        win=tk.Toplevel(self); self.mouse_test_win=win
        win.title("Controller Test Lab · Mouse tester"); win.geometry("820x610"); win.minsize(650,480); win.configure(bg=BG)
        win.protocol("WM_DELETE_WINDOW",lambda:(setattr(self,"mouse_test_win",None),win.destroy()))
        outer=tk.Frame(win,bg=BG,padx=22,pady=20); outer.pack(fill="both",expand=True)
        tk.Label(outer,text="Mouse & scroll tester",bg=BG,fg=TEXT,font=("DejaVu Sans",20,"bold")).pack(anchor="w")
        tk.Label(outer,text="Move through the test area, click each button, and roll the wheel. Rate numbers are approximate event cadence, not hardware latency certification.",bg=BG,fg=MUTED,wraplength=760,justify="left",font=("DejaVu Sans",9)).pack(anchor="w",pady=(4,12))
        stat=tk.Frame(outer,bg=PANEL,highlightbackground=EDGE,highlightthickness=1,padx=12,pady=10); stat.pack(fill="x")
        values=tk.Label(stat,text="Position: —    Movement: —    Clicks: 0    Wheel: 0",bg=PANEL,fg=TEXT,font=("DejaVu Sans Mono",10)); values.pack(anchor="w")
        area=tk.Canvas(outer,bg=FIELD_BG,highlightbackground=EDGE,highlightthickness=1,cursor="crosshair"); area.pack(fill="both",expand=True,pady=(12,0))
        state={"x":None,"y":None,"moves":0,"clicks":0,"wheel":0,"last":time.monotonic(),"hz":0.0,"delta":0.0}
        dot=[None]
        def motion(e):
            now=time.monotonic(); state["moves"]+=1
            if state["x"] is not None:
                dx=e.x-state["x"]; dy=e.y-state["y"]; state["delta"]=math.hypot(dx,dy)
                dt=now-state["last"]
                if dt>0: state["hz"]=.25*(1/dt)+.75*state["hz"]
            state["x"],state["y"],state["last"]=e.x,e.y,now
            area.delete("cursor")
            area.create_oval(e.x-14,e.y-14,e.x+14,e.y+14,fill="#dceaff",outline="#2878e6",width=2,tags="cursor")
            area.create_line(e.x-22,e.y,e.x+22,e.y,fill="#2878e6",tags="cursor")
            area.create_line(e.x,e.y-22,e.x,e.y+22,fill="#2878e6",tags="cursor")
            values.configure(text=f"Position: {e.x}, {e.y}    Δ last: {state['delta']:.1f}px    Move events: {state['moves']}    ~{state['hz']:.0f} events/s    Clicks: {state['clicks']}    Wheel: {state['wheel']}")
        def click(e):
            state["clicks"]+=1
            values.configure(text=f"Position: {e.x}, {e.y}    Δ last: {state['delta']:.1f}px    Move events: {state['moves']}    ~{state['hz']:.0f} events/s    Clicks: {state['clicks']}    Wheel: {state['wheel']} (button {e.num})")
            area.create_text(e.x,e.y+27,text=f"{e.num} ✓",fill="#174ea6",tags="cursor",font=("DejaVu Sans",9,"bold"))
        def wheel(e):
            state["wheel"]+= (1 if getattr(e,"delta",0)>0 or getattr(e,"num",0)==4 else -1)
            values.configure(text=f"Position: {state['x']}, {state['y']}    Δ last: {state['delta']:.1f}px    Move events: {state['moves']}    ~{state['hz']:.0f} events/s    Clicks: {state['clicks']}    Wheel: {state['wheel']}")
        area.bind("<Motion>",motion)
        for button in (1,2,3,4,5): area.bind(f"<Button-{button}>",click if button in (1,2,3) else wheel)
        area.bind("<MouseWheel>",wheel)
        win.bind("<Escape>",lambda _e:(setattr(self,"mouse_test_win",None),win.destroy()))
        win.focus_force()

    # ----- Controller device handling -----
    def _show_no_controller(self, text):
        for widget in self.axes_area.winfo_children(): widget.destroy()
        self.axis_bars.clear(); self.axis_values.clear()
        for widget in self.buttons_grid.winfo_children(): widget.destroy()
        self.button_widgets.clear()
        self.status.configure(text=text, fg=ORANGE)
        self.live_badge.configure(text="WAITING", bg=BADGE, fg=ORANGE)
        self._draw_drift_graph()

    def scan_devices(self):
        old_path = self.selected.path if self.selected else None
        for device in self.devices: device.close()
        self.devices, self.denied_count = find_gamepads()
        self.selected = None
        labels = [f"{d.name}  ·  {d.path.split('/')[-1]}" for d in self.devices]
        self.device_combo.configure(values=labels)
        pick = next((i for i, d in enumerate(self.devices) if d.path == old_path), 0 if self.devices else -1)
        if pick >= 0:
            self.device_combo.current(pick)
            self.selected = self.devices[pick]
            self.setup_device_view()
            self.status.configure(text="CONNECTED  /  live input ready", fg=GREEN)
            self.path_label.configure(text=self.selected.path)
            self.footer.configure(text=f"Controller: {self.selected.name}  ·  raw axes shown without a software deadzone")
        else:
            self.device_combo.set("")
            msg = "No readable gamepad found. Connect it and rescan."
            if self.denied_count: msg += f"  {self.denied_count} input node(s) were permission-denied."
            self._show_no_controller(msg)
            self.path_label.configure(text="/dev/input/event*")
            self.footer.configure(text="No controller found · audio tools remain available on the Audio devices tab")

    def change_device(self, _event=None):
        index = self.device_combo.current()
        if index < 0 or index >= len(self.devices): return
        self.selected = self.devices[index]
        self.calibration.clear()
        for history in self.drift_history.values(): history.clear()
        self.setup_device_view()
        self.status.configure(text="CONNECTED  /  live input ready", fg=GREEN)
        self.path_label.configure(text=self.selected.path)
        self.footer.configure(text=f"Controller: {self.selected.name}")

    def setup_device_view(self):
        dev = self.selected
        for widget in self.axes_area.winfo_children(): widget.destroy()
        self.axis_bars.clear(); self.axis_values.clear()
        relevant_axes = [c for c in dev.axes if c in AXIS_LABELS]
        if not relevant_axes:
            tk.Label(self.axes_area, text="No standard analog axes reported.", bg=PANEL, fg=MUTED).pack(anchor="w")
        for code in relevant_axes:
            line = tk.Frame(self.axes_area, bg=PANEL); line.pack(fill="x", pady=3)
            label = AXIS_LABELS.get(code, f"Axis {code}")
            tk.Label(line, text=label, width=19, anchor="w", bg=PANEL, fg=TEXT, font=("DejaVu Sans", 8)).pack(side="left")
            canvas = tk.Canvas(line, width=170, height=10, bg=GRID_2, highlightthickness=0, bd=0)
            canvas.pack(side="left", fill="x", expand=True, padx=(6, 8))
            canvas.create_line(85, 0, 85, 10, fill="#a9b5c4", width=1)
            bar = canvas.create_rectangle(82, 1, 88, 9, fill=CYAN, outline="")
            value = tk.Label(line, text="—", width=15, anchor="e", bg=PANEL, fg=MUTED, font=("DejaVu Sans Mono", 8))
            value.pack(side="right")
            self.axis_bars[code] = (canvas, bar)
            self.axis_values[code] = value
        for widget in self.buttons_grid.winfo_children(): widget.destroy()
        self.button_widgets.clear()
        codes = [c for c in dev.key_codes if (BTN_JOYSTICK <= c <= 0x13F or 0x220 <= c <= 0x223 or 0x2C0 <= c <= 0x2E7)]
        priority = {0x130:0,0x131:1,0x133:2,0x134:3,0x136:4,0x137:5,0x138:6,0x139:7,0x13A:8,0x13B:9,0x13D:10,0x13E:11,0x13C:12}
        codes.sort(key=lambda c: (priority.get(c, 99), c))
        if not codes:
            tk.Label(self.buttons_grid, text="No standard button codes.", bg=PANEL, fg=MUTED).pack(anchor="w")
        else:
            for i, code in enumerate(codes):
                label = BUTTON_LABELS.get(code, f"Button {code}")
                tile = tk.Label(self.buttons_grid, text=label, bg=PANEL_2, fg=MUTED, padx=5, pady=5,
                                relief="flat", font=("DejaVu Sans", 8), width=12, anchor="center")
                tile.grid(row=i//3, column=i%3, padx=2, pady=2, sticky="ew")
                self.button_widgets[code] = tile
            for col in range(3): self.buttons_grid.grid_columnconfigure(col, weight=1)
        self._draw_stick(self.left_canvas, dev.normal(ABS_X), dev.normal(ABS_Y))
        self._draw_stick(self.right_canvas, dev.normal(ABS_RX) if ABS_RX in dev.axes else .5, dev.normal(ABS_RY) if ABS_RY in dev.axes else .5)
        self.live_badge.configure(text="LIVE", bg=GOOD_BG, fg=GREEN)
        self._update_drift_labels(dev)

    def _draw_stick(self, canvas, nx, ny, magnify_enabled=None, magnification=None):
        """Draw a dot-matrix stick field with a subtle magnification lens.

        The dots stay on a fixed grid. The live axis position acts like a lens:
        dots near that point grow smoothly while distant dots stay small. This
        deliberately avoids relying on a single oversized moving cursor.
        """
        canvas.delete("all")
        try:
            w = max(180, canvas.winfo_width())
            h = max(120, canvas.winfo_height() or 128)
        except tk.TclError:
            w, h = 210, 128
        cx, cy = w / 2.0, h / 2.0
        radius = max(20.0, min(w - 24.0, h - 12.0) / 2.0)
        nx = max(0.0, min(1.0, float(nx)))
        ny = max(0.0, min(1.0, float(ny)))
        px = cx + (nx - 0.5) * radius * 2.0
        py = cy + (ny - 0.5) * radius * 2.0
        enabled = self.magnifying_dots_enabled if magnify_enabled is None else bool(magnify_enabled)
        strength = self.magnifying_strength if magnification is None else float(magnification)

        # Very light guides provide orientation without competing with the dots.
        canvas.create_oval(cx-radius, cy-radius, cx+radius, cy+radius, outline=GRID_2, width=1)
        canvas.create_oval(cx-radius*0.50, cy-radius*0.50, cx+radius*0.50, cy+radius*0.50, outline=GRID_2, width=1)
        canvas.create_line(cx-radius, cy, cx+radius, cy, fill=GRID_2, width=1)
        canvas.create_line(cx, cy-radius, cx, cy+radius, fill=GRID_2, width=1)

        spacing = 10.5
        lens_radius = max(8.0, radius * 0.31)
        # The dot lattice is constrained to the circular stick travel area.
        x = cx - radius + spacing / 2.0
        while x <= cx + radius - spacing / 2.0:
            y = cy - radius + spacing / 2.0
            while y <= cy + radius - spacing / 2.0:
                field_dist = math.sqrt((x-cx)**2 + (y-cy)**2)
                if field_dist <= radius - 1.0:
                    d = math.sqrt((x-px)**2 + (y-py)**2)
                    influence = math.exp(-2.2 * (d / lens_radius) ** 2) if enabled else 0.0
                    dot_r = 1.25 + min(1.9, 0.95 * strength * influence)
                    # Blend the cool gray lattice toward the app's blue accent.
                    blend = min(1.0, influence * (0.48 if enabled else 0.0))
                    base = tuple(int(DOT_BASE[i:i+2], 16) for i in (1, 3, 5))
                    accent = (40, 120, 230)
                    color = "#%02x%02x%02x" % tuple(round(base[i] * (1-blend) + accent[i] * blend) for i in range(3))
                    canvas.create_oval(x-dot_r, y-dot_r, x+dot_r, y+dot_r, fill=color, outline="")
                y += spacing
            x += spacing

        # A compact hollow locator marks the exact reported axis position.
        # Even with magnification disabled, the live position remains visible.
        locator_r = 3.1
        canvas.create_oval(px-locator_r, py-locator_r, px+locator_r, py+locator_r,
                           outline=CYAN if enabled else DOT_RING, width=1.2)
        canvas.create_oval(cx-2.1, cy-2.1, cx+2.1, cy+2.1, outline=MUTED, width=1)

    def center_offset(self, code):
        dev = self.selected
        if not dev or code not in dev.axes: return 0.0, 0
        raw = dev.axis_values.get(code, dev.range_for(code)[0])
        _v, lo, hi, *_ = dev.range_for(code)
        mid = (lo + hi) / 2.0
        span = max(1.0, float(hi - lo))
        pct = (raw - mid) / span * 100.0
        return pct, int(round(raw - mid))

    def baseline_delta(self, code):
        dev = self.selected
        if not dev or code not in dev.axes: return 0.0, 0
        raw = dev.axis_values.get(code, dev.range_for(code)[0])
        base = self.calibration.get(code)
        if base is None:
            _v, lo, hi, *_ = dev.range_for(code)
            base = (lo + hi) / 2.0
        delta = raw - base
        _v, lo, hi, *_ = dev.range_for(code)
        pct = delta / max(1.0, float(hi - lo)) * 100.0
        return pct, int(round(delta))

    def start_calibration(self):
        dev = self.selected
        if not dev:
            messagebox.showinfo(APP_NAME, "Connect and select a controller first.", parent=self); return
        codes = [c for c in (ABS_X, ABS_Y, ABS_RX, ABS_RY) if c in dev.axes]
        if not codes:
            self.calibration_status.configure(text="This controller does not expose standard stick axes.", fg=ORANGE); return
        self.calibration_active = True
        self.calibration_started = time.monotonic()
        self.calibration_samples = {c: [] for c in codes}
        self.calibration_status.configure(text="Calibrating for 2 seconds · lift your thumbs and leave both sticks untouched…", fg=ORANGE)

    def _sample_drift(self, dev):
        now = time.monotonic()
        for code in self.drift_history:
            if code not in dev.axes: continue
            pct, _raw = self.baseline_delta(code)
            self.drift_history[code].append((now, pct))
            history = self.drift_history[code]
            while history and now - history[0][0] > 5.0: history.popleft()
        if self.calibration_active:
            for code, values in self.calibration_samples.items():
                values.append(dev.axis_values.get(code, dev.range_for(code)[0]))
            elapsed = now - self.calibration_started
            if elapsed >= 2.0:
                for code, values in self.calibration_samples.items():
                    if values: self.calibration[code] = sum(values) / len(values)
                self.calibration_active = False
                self.calibration_status.configure(text="Baseline captured. Live raw deltas and 5-second movement peaks are shown below the stick diagrams.", fg=GREEN)
        self._update_drift_labels(dev)
        self._draw_drift_graph()

    def _update_drift_labels(self, dev):
        pairs = ((ABS_X, ABS_Y, self.left_offset, self.left_baseline, self.left_peak),
                 (ABS_RX, ABS_RY, self.right_offset, self.right_baseline, self.right_peak))
        now = time.monotonic()
        for xc, yc, center_label, base_label, peak_label in pairs:
            if xc not in dev.axes or yc not in dev.axes:
                center_label.configure(text="Axes unavailable", fg=MUTED)
                base_label.configure(text="Baseline delta —", fg=MUTED)
                peak_label.configure(text="5 s movement peak —", fg=MUTED)
                continue
            px, rx = self.center_offset(xc); py, ry = self.center_offset(yc)
            center_label.configure(text=f"Midpoint offset  X {px:+.4f}% ({rx:+d})  ·  Y {py:+.4f}% ({ry:+d})",
                                   fg=ORANGE if (abs(px) > .05 or abs(py) > .05) else CYAN)
            bpx, brx = self.baseline_delta(xc); bpy, bry = self.baseline_delta(yc)
            base_label.configure(text=f"From baseline  X {bpx:+.5f}% ({brx:+d} raw)  ·  Y {bpy:+.5f}% ({bry:+d} raw)", fg=TEXT)
            peaks = []
            for code in (xc, yc):
                vals = [abs(v) for t, v in self.drift_history[code] if now-t <= 5.0]
                peaks.append(max(vals) if vals else 0.0)
            peak_label.configure(text=f"5 s peak  X {peaks[0]:.5f}%  ·  Y {peaks[1]:.5f}%", fg=MUTED)

    def change_drift_scale(self, _event=None):
        value = self.scale_combo.get().replace("±", "").replace("%", "")
        try: self.drift_scale = float(value)
        except ValueError: self.drift_scale = 0.1
        self._draw_drift_graph()

    def _draw_drift_graph(self):
        if not hasattr(self, "drift_canvas"): return
        c = self.drift_canvas; c.delete("all")
        w = max(300, c.winfo_width()); h = max(70, c.winfo_height())
        mid = h / 2
        c.create_line(0, mid, w, mid, fill=GRID, width=1)
        for frac in (.25, .75): c.create_line(0, h*frac, w, h*frac, fill=GRID_2, width=1)
        c.create_text(7, 7, text=f"+{self.drift_scale:g}%", fill=MUTED, anchor="nw", font=("DejaVu Sans", 7))
        c.create_text(7, h-7, text=f"−{self.drift_scale:g}%", fill=MUTED, anchor="sw", font=("DejaVu Sans", 7))
        colors = {ABS_X:CYAN, ABS_Y:"#9e8cff", ABS_RX:GREEN, ABS_RY:ORANGE}
        now = time.monotonic()
        for code, color in colors.items():
            history = [(t, v) for t, v in self.drift_history[code] if now-t <= 5.0]
            if len(history) < 2: continue
            pts=[]
            for t, v in history:
                x = w - min(5.0, now-t)/5.0*w
                y = mid - max(-self.drift_scale, min(self.drift_scale, v))/max(0.0000001, self.drift_scale)*(h/2-7)
                pts.extend((x,y))
            c.create_line(*pts, fill=color, width=2, smooth=False)
        legend = [(ABS_X,"LX",CYAN),(ABS_Y,"LY","#9e8cff"),(ABS_RX,"RX",GREEN),(ABS_RY,"RY",ORANGE)]
        x = max(110, w-230)
        for code, name, color in legend:
            c.create_rectangle(x, 5, x+7, 12, fill=color, outline="")
            c.create_text(x+11, 9, text=name, fill=TEXT, anchor="w", font=("DejaVu Sans", 7))
            x += 45

    def poll(self):
        dev = self.selected
        if dev and dev.fd is not None:
            try:
                while True:
                    try: data = os.read(dev.fd, EVENT.size * 128)
                    except BlockingIOError: break
                    if not data: break
                    usable = len(data) - (len(data) % EVENT.size)
                    for offset in range(0, usable, EVENT.size):
                        _sec, _usec, typ, code, value = EVENT.unpack_from(data, offset)
                        if typ == EV_KEY:
                            if value: dev.pressed.add(code)
                            else: dev.pressed.discard(code)
                            dev.button_events_seen += 1
                        elif typ == EV_ABS:
                            dev.axis_values[code] = value
                            dev.axis_events_seen += 1
                self.update_view(dev)
                self._sample_drift(dev)
            except OSError as exc:
                self.status.configure(text=f"Controller disconnected ({exc.strerror or 'input error'}). Rescan.", fg=RED)
                self.live_badge.configure(text="OFFLINE", bg=BAD_BG, fg=RED)
        self.poll_after = self.after(18, self.poll)

    def update_view(self, dev):
        if dev is not self.selected: return
        for code, (canvas, bar) in self.axis_bars.items():
            n = dev.normal(code); x = int(n * max(20, canvas.winfo_width()))
            cw = max(20, canvas.winfo_width())
            canvas.coords(bar, max(0, min(cw-6, x-3)), 1, max(5, min(cw, x+3)), 9)
            canvas.itemconfigure(bar, fill=ORANGE if code in (ABS_HAT0X, ABS_HAT0Y, ABS_HAT1X, ABS_HAT1Y) else CYAN)
            raw = dev.axis_values.get(code, dev.range_for(code)[0])
            pct = (n-.5)*200.0
            self.axis_values[code].configure(text=f"{pct:+.4f}%  ·  {raw}", fg=CYAN if abs(pct) < .05 else TEXT)
        if ABS_X in dev.axes and ABS_Y in dev.axes: self._draw_stick(self.left_canvas, dev.normal(ABS_X), dev.normal(ABS_Y))
        if ABS_RX in dev.axes and ABS_RY in dev.axes: self._draw_stick(self.right_canvas, dev.normal(ABS_RX), dev.normal(ABS_RY))
        for code, widget in self.button_widgets.items():
            down = code in dev.pressed
            widget.configure(bg=GOOD_BG if down else PANEL_2, fg=GREEN if down else MUTED,
                             text=("● " if down else "○ ") + BUTTON_LABELS.get(code, f"Button {code}"))
        if ABS_HAT0X in dev.axes or ABS_HAT0Y in dev.axes:
            hx = dev.axis_values.get(ABS_HAT0X, 0); hy = dev.axis_values.get(ABS_HAT0Y, 0)
            parts = []
            if hy < 0: parts.append("UP")
            if hy > 0: parts.append("DOWN")
            if hx < 0: parts.append("LEFT")
            if hx > 0: parts.append("RIGHT")
            self.dpad_label.configure(text="  +  ".join(parts) if parts else "D-pad centered", fg=GREEN if parts else MUTED)
        elif any(c in dev.pressed for c in (0x220,0x221,0x222,0x223)):
            labels = [BUTTON_LABELS[c] for c in (0x220,0x221,0x222,0x223) if c in dev.pressed]
            self.dpad_label.configure(text="  +  ".join(labels), fg=GREEN)
        else: self.dpad_label.configure(text="No D-pad axis", fg=MUTED)
        if dev.button_events_seen or dev.axis_events_seen:
            self.footer.configure(text=f"Live input active  ·  {dev.button_events_seen} button events  ·  {dev.axis_events_seen} axis events")

    # ----- Rumble -----
    def test_rumble(self):
        dev = self.selected
        if not dev:
            messagebox.showinfo(APP_NAME, "Connect a controller and select it first.", parent=self); return
        fd = None
        try:
            fd = os.open(dev.path, os.O_RDWR | os.O_NONBLOCK | getattr(os, "O_CLOEXEC", 0))
            class Trigger(ctypes.Structure): _fields_ = [("button", ctypes.c_ushort), ("interval", ctypes.c_ushort)]
            class Replay(ctypes.Structure): _fields_ = [("length", ctypes.c_ushort), ("delay", ctypes.c_ushort)]
            class Rumble(ctypes.Structure): _fields_ = [("strong_magnitude", ctypes.c_ushort), ("weak_magnitude", ctypes.c_ushort)]
            class EffectUnion(ctypes.Union): _fields_ = [("rumble", Rumble), ("raw", ctypes.c_ubyte * 32), ("align", ctypes.c_void_p)]
            class Effect(ctypes.Structure):
                _fields_ = [("type", ctypes.c_ushort), ("id", ctypes.c_short), ("direction", ctypes.c_ushort),
                            ("trigger", Trigger), ("replay", Replay), ("u", EffectUnion)]
            effect = Effect(); effect.type = 0x50; effect.id = -1; effect.direction = 0
            effect.trigger = Trigger(0, 0); effect.replay = Replay(450, 0); effect.u.rumble = Rumble(0x9000, 0x6000)
            buf = bytearray(ctypes.string_at(ctypes.addressof(effect), ctypes.sizeof(effect)))
            fcntl.ioctl(fd, ioc_write("E", 0x80, ctypes.sizeof(Effect)), buf, True)
            effect_id = struct.unpack_from("h", buf, 2)[0]
            now=time.time(); sec=int(now); usec=int((now-sec)*1_000_000)
            os.write(fd, EVENT.pack(sec, usec, EV_FF, effect_id, 1))
            self.status.configure(text="Vibration command sent.", fg=GREEN)
            self.rumble_button.configure(state="disabled", text="Testing…")
            def stop_rumble():
                try:
                    t=time.time(); ss=int(t); us=int((t-ss)*1_000_000)
                    os.write(fd, EVENT.pack(ss, us, EV_FF, effect_id, 0))
                    erase=bytearray(struct.pack("i", effect_id))
                    fcntl.ioctl(fd, ioc_write("E", 0x81, struct.calcsize("i")), erase, True)
                except OSError: pass
                try: os.close(fd)
                except OSError: pass
                self.rumble_button.configure(state="normal", text="Test vibration")
            self.rumble_after = self.after(550, stop_rumble)
        except OSError as exc:
            if fd is not None:
                try: os.close(fd)
                except OSError: pass
            messagebox.showwarning(APP_NAME, "This controller or driver may not provide force feedback.\n\n" + str(exc), parent=self)
            self.status.configure(text="Vibration unavailable · button and axis tests still work", fg=ORANGE)
            self.rumble_button.configure(state="normal", text="Test vibration")

    # ----- Audio discovery -----
    def _run_quiet(self, cmd, timeout=3):
        try:
            return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout, check=False)
        except (OSError, subprocess.TimeoutExpired): return None

    def scan_audio_devices(self):
        outputs, inputs, backend = [], [], ""
        pactl = shutil.which("pactl")
        if pactl:
            try:
                sinks_r = self._run_quiet([pactl, "-f", "json", "list", "sinks"])
                srcs_r = self._run_quiet([pactl, "-f", "json", "list", "sources"])
                defaults_r = self._run_quiet([pactl, "info"])
                default_sink = default_source = ""
                if defaults_r and defaults_r.returncode == 0:
                    for line in defaults_r.stdout.splitlines():
                        if line.startswith("Default Sink:"): default_sink=line.split(":",1)[1].strip()
                        elif line.startswith("Default Source:"): default_source=line.split(":",1)[1].strip()
                if sinks_r and sinks_r.returncode == 0:
                    for item in json.loads(sinks_r.stdout):
                        name=item.get("name", ""); desc=item.get("description") or name
                        outputs.append({"name":name,"description":desc,"default":name==default_sink,"id":item.get("index")})
                if srcs_r and srcs_r.returncode == 0:
                    for item in json.loads(srcs_r.stdout):
                        name=item.get("name", "")
                        if name.endswith(".monitor") or item.get("monitor_of_sink", -1) not in (-1, None): continue
                        inputs.append({"name":name,"description":item.get("description") or name,"default":name==default_source,"id":item.get("index")})
                if outputs or inputs: backend = "PipeWire/PulseAudio"
            except (ValueError, TypeError): pass
            # Older PulseAudio-compatible pactl versions may not support JSON output.
            if not outputs:
                r=self._run_quiet([pactl, "list", "short", "sinks"])
                if r and r.returncode == 0:
                    for line in r.stdout.splitlines():
                        parts=line.split("\t")
                        if len(parts) >= 2 and parts[1].strip():
                            name=parts[1].strip()
                            outputs.append({"name":name,"description":name,"default":name==default_sink,"id":parts[0]})
            if not inputs:
                r=self._run_quiet([pactl, "list", "short", "sources"])
                if r and r.returncode == 0:
                    for line in r.stdout.splitlines():
                        parts=line.split("\t")
                        if len(parts) >= 2 and parts[1].strip():
                            name=parts[1].strip()
                            if name.endswith(".monitor"): continue
                            inputs.append({"name":name,"description":name,"default":name==default_source,"id":parts[0]})
            if outputs or inputs: backend = backend or "PulseAudio-compatible audio service"
        # ALSA fallback discovery. Selection remains system-default when a Pulse-compatible server isn't available.
        if not outputs and shutil.which("aplay"):
            r=self._run_quiet([shutil.which("aplay"),"-l"])
            if r and ("card" in r.stdout.lower()):
                outputs=[{"name":"default","description":"System default output (ALSA)","default":True,"id":None}]
                backend="ALSA"
        if not inputs and shutil.which("arecord"):
            r=self._run_quiet([shutil.which("arecord"),"-l"])
            if r and "card" in r.stdout.lower():
                inputs=[{"name":"default","description":"System default microphone (ALSA)","default":True,"id":None}]
                backend = (backend + " + ALSA fallback").strip(" +")
        # Keep system-default choices visible if no discovery utility is installed.
        if not outputs: outputs=[{"name":"default","description":"System default output (not enumerated)","default":True,"id":None}]
        if not inputs: inputs=[{"name":"default","description":"System default input (not enumerated)","default":True,"id":None}]
        old_out = self.output_sink_name; old_in = self.mic_source_name
        self.audio_outputs, self.audio_inputs = outputs, inputs
        out_labels=[("★ " if d.get("default") else "") + d["description"] for d in outputs]
        in_labels=[("★ " if d.get("default") else "") + d["description"] for d in inputs]
        self.output_combo.configure(values=out_labels); self.mic_combo.configure(values=in_labels)
        out_pick=next((i for i,d in enumerate(outputs) if d["name"]==old_out), next((i for i,d in enumerate(outputs) if d.get("default")),0))
        in_pick=next((i for i,d in enumerate(inputs) if d["name"]==old_in), next((i for i,d in enumerate(inputs) if d.get("default")),0))
        self.output_combo.current(out_pick); self.mic_combo.current(in_pick)
        self.output_sink_name=outputs[out_pick]["name"]; self.mic_source_name=inputs[in_pick]["name"]
        self.output_details.configure(text=f"{len(outputs)} output choice(s) found.\nSelected: {outputs[out_pick]['description']}\n\nDefault output is marked ★ when discovered.")
        self.input_details.configure(text=f"{len(inputs)} input choice(s) found.\nSelected: {inputs[in_pick]['description']}\n\nInput meter starts only when you press Start microphone test.")
        available = backend or "Audio backend not fully detected"
        self.audio_summary.configure(text=f"Discovery backend: {available}. Enumerated {len(outputs)} output choice(s) and {len(inputs)} input choice(s). Utilities used when installed: pactl, paplay/pw-play, aplay, parec/arecord.")
        self.speaker_status.configure(text="Choose an output and play a short tone. Audio is generated temporarily and removed after playback.", fg=MUTED)
        if hasattr(self,"footer"): self.footer.configure(text=f"Audio scan complete · {len(outputs)} outputs · {len(inputs)} inputs · {available}")

    def change_output(self, _event=None):
        i=self.output_combo.current()
        if 0 <= i < len(self.audio_outputs):
            self.output_sink_name=self.audio_outputs[i]["name"]
            self.output_details.configure(text=f"Selected: {self.audio_outputs[i]['description']}\nBackend name: {self.output_sink_name}")

    def change_mic(self, _event=None):
        i=self.mic_combo.current()
        if 0 <= i < len(self.audio_inputs):
            self.mic_source_name=self.audio_inputs[i]["name"]
            self.input_details.configure(text=f"Selected: {self.audio_inputs[i]['description']}\nBackend name: {self.mic_source_name}")

    def _make_test_tone(self):
        if self.audio_tone_path and os.path.exists(self.audio_tone_path): return self.audio_tone_path
        fd,path=tempfile.mkstemp(prefix="controller-test-tone-", suffix=".wav"); os.close(fd)
        rate=44100; duration=0.65
        with wave.open(path,"wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)
            samples=array("h")
            total=int(rate*duration)
            for i in range(total):
                fade=min(1.0,i/(rate*.04),(total-i)/(rate*.06))
                val=int(5000*max(0.0,fade)*math.sin(2*math.pi*440*i/rate))
                samples.append(val)
            if sys.byteorder != "little": samples.byteswap()
            w.writeframes(samples.tobytes())
        self.audio_tone_path=path
        return path

    def test_speaker(self):
        sink=self.output_sink_name or "default"
        tone=self._make_test_tone()
        cmds=[]
        if shutil.which("paplay"):
            cmd=[shutil.which("paplay")]
            if sink and sink != "default": cmd += ["--device", sink]
            cmds.append(cmd+[tone])
        if shutil.which("pw-play"):
            cmd=[shutil.which("pw-play")]
            if sink and sink != "default": cmd += ["--target", sink]
            cmds.append(cmd+[tone])
        if shutil.which("aplay"):
            cmds.append([shutil.which("aplay"), "-q", tone])
        if not cmds:
            messagebox.showwarning(APP_NAME, "No audio playback utility was found. Install pulseaudio-utils or alsa-utils, then rescan.", parent=self); return
        self.speaker_status.configure(text="Playing 440 Hz test tone…", fg=CYAN)
        def worker():
            errors=[]; ok=False
            for cmd in cmds:
                try:
                    r=subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=4, check=False)
                    if r.returncode==0: ok=True; break
                    errors.append((r.stderr or b"").decode("utf-8","replace").strip())
                except (OSError, subprocess.TimeoutExpired) as exc: errors.append(str(exc))
            try: os.unlink(tone)
            except OSError: pass
            self.audio_tone_path=None
            msg="Tone played. Did you hear it?" if ok else "Playback failed. Check the selected output and system volume. " + next((x for x in errors if x), "No audio backend accepted the test tone.")[:180]
            self.after(0, lambda m=msg, good=ok: self.speaker_status.configure(text=m, fg=GREEN if good else ORANGE))
        threading.Thread(target=worker, daemon=True).start()

    def toggle_mic_test(self):
        if self.audio_running:
            self.stop_mic_test()
            return
        if not any(shutil.which(x) for x in ("parec", "arecord")):
            messagebox.showwarning(APP_NAME, "No microphone capture utility found. Install pulseaudio-utils (recommended) or alsa-utils, then click Scan.", parent=self); return
        source=self.mic_source_name or "default"
        if shutil.which("parec"):
            cmd=[shutil.which("parec"), "--raw", "--format=s16le", "--rate=16000", "--channels=1"]
            if source != "default": cmd += ["--device", source]
        else: cmd=[shutil.which("arecord"), "-q", "-D", "default", "-t", "raw", "-f", "S16_LE", "-r", "16000", "-c", "1"]
        try:
            proc=subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=0)
        except OSError as exc:
            messagebox.showwarning(APP_NAME, "Could not open the microphone: " + str(exc), parent=self); return
        self.audio_proc=proc; self.audio_running=True; self.audio_error=""
        with self.audio_lock: self.audio_level_db=-60.0
        self.mic_button.configure(text="Stop microphone test")
        self.mic_status.configure(text="Listening locally… speak or tap the mic to see the level move.", fg=CYAN)
        def reader():
            try:
                while self.audio_running and proc.poll() is None:
                    chunk=proc.stdout.read(4096) if proc.stdout else b""
                    if not chunk: break
                    samples=array("h"); samples.frombytes(chunk[:len(chunk)//2*2])
                    if sys.byteorder != "little": samples.byteswap()
                    if samples:
                        mean_square=sum(int(x)*int(x) for x in samples)/len(samples)
                        rms=math.sqrt(mean_square)
                        db=20*math.log10(max(1.0,rms)/32768.0)
                        with self.audio_lock: self.audio_level_db=max(-60.0,min(0.0,db))
            except Exception as exc:
                self.audio_error=str(exc)
            finally:
                if self.audio_running:
                    code=proc.poll()
                    self.audio_error=self.audio_error or ("Capture ended (code %s). Check mic permissions/device."%code)
                    self.after(0, self._mic_finished)
        self.audio_thread=threading.Thread(target=reader,daemon=True); self.audio_thread.start()

    def stop_mic_test(self):
        self.audio_running=False
        proc=self.audio_proc; self.audio_proc=None
        if proc:
            try: proc.terminate()
            except OSError: pass
            try: proc.wait(timeout=.4)
            except subprocess.TimeoutExpired:
                try: proc.kill()
                except OSError: pass
        self.mic_button.configure(text="Start microphone test")
        with self.audio_lock: self.audio_level_db=-60.0
        self._draw_mic_meter()
        self.mic_status.configure(text="Mic monitor stopped. Audio is not saved.", fg=MUTED)

    def _mic_finished(self):
        if not self.audio_running: return
        self.audio_running=False; self.audio_proc=None
        self.mic_button.configure(text="Start microphone test")
        self.mic_status.configure(text=self.audio_error or "Microphone capture ended. Check the selected input.", fg=ORANGE)

    def update_audio_meter(self):
        if hasattr(self,"mic_meter"):
            with self.audio_lock: db=self.audio_level_db
            self._draw_mic_meter(db)
            if self.audio_running:
                self.mic_status.configure(text=f"Live level  {db:.1f} dBFS  ·  no audio saved", fg=GREEN if db > -45 else CYAN)
        self.audio_meter_after = self.after(45, self.update_audio_meter)

    def _draw_mic_meter(self, db=None):
        if not hasattr(self,"mic_meter"): return
        if db is None:
            with self.audio_lock: db=self.audio_level_db
        c=self.mic_meter; c.delete("all")
        w=max(120,c.winfo_width()); h=max(22,c.winfo_height())
        c.create_rectangle(0,0,w,h,fill=CANVAS,outline="")
        frac=max(0.0,min(1.0,(db+60)/60))
        color=RED if db>-8 else (GREEN if db>-35 else CYAN)
        c.create_rectangle(0,0,int(w*frac),h,fill=color,outline="")
        c.create_text(8,h/2,text=f"INPUT LEVEL  {db:.1f} dBFS",fill=TEXT,anchor="w",font=("DejaVu Sans Mono",8,"bold"))

    def on_close(self):
        for job_name in ("poll_after", "audio_meter_after", "screen_test_after", "rumble_after"):
            job = getattr(self, job_name, None)
            if job:
                try: self.after_cancel(job)
                except Exception: pass
        for child in (self.screen_test_win, self.keyboard_test_win, self.mouse_test_win):
            if child and child.winfo_exists():
                try: child.destroy()
                except tk.TclError: pass
        if self.screen_test_after:
            try: self.after_cancel(self.screen_test_after)
            except Exception: pass
        if self.rumble_after:
            try: self.after_cancel(self.rumble_after)
            except Exception: pass
        if self.audio_running: self.stop_mic_test()
        if self.audio_tone_path:
            try: os.unlink(self.audio_tone_path)
            except OSError: pass
        for dev in self.devices: dev.close()
        self.destroy()


def main():
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
